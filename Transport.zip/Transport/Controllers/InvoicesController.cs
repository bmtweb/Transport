﻿using System;
using System.Data.Common;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using PagedList;
using Transport.Models;
namespace Transport.Controllers
{
    [Authorize]
    public class InvoicesController : Controller
    {
        int pageSize = 10;
        int Branch_id = 0;
        Models.SalesConn con;
        public ActionResult Index(int? page, int? comp, string filter, string value)
        {
            int pageNumber = (page ?? 1);
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }
            var cookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();

            var rep = con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray();
            ViewBag.Companies = new SelectList(rep, "Id", "Name", comp);
            ViewBag.company_id = comp;
            if (Session.Count > 0)
            {
                string sdata = Session["Type"].ToString();
                ViewBag.RId = sdata;
            }
            else
            {
                Session.Abandon();
                Session.Clear();
                TempData["message1"] = "Your session is timeout please login again for continue !";
                return RedirectToAction("Logout", "Home");
            }

            if (value == "" || value == null)
            {
                var LQr = con.Invoices.Where(x => (x.Invoice_Date >= dfrom.Value && x.Invoice_Date <= dto.Value) && x.Branch_Id == Branch_id && x.Transport_Id > 0 && (comp == null ? true : x.Company_Id == comp.Value)).OrderByDescending(x => x.Id).ToPagedList(pageNumber, pageSize);
                return View(LQr);
            }
            else {
                var LQs = con.Invoices.Where(x => (x.Invoice_Date >= dfrom.Value && x.Invoice_Date <= dto.Value) && x.Branch_Id == Branch_id && x.Transport_Id > 0 && (comp == null ? true : x.Company_Id == comp.Value)).ToList();
                return View(LQs.Where(x => GetPropertyValue(x, filter, value)).ToPagedList(pageNumber, pageSize));
            }
        }

        [AcceptVerbs(HttpVerbs.Get )]
        public JsonResult TagSearch(string term)
        {
             //Get Tags from database
            var res = (from m in con.Vehicles
                       select m.Name);
            var tlist = res.Where(n => n.ToLower().StartsWith(term.ToLower()));
            return this.Json(tlist.Where(t => t.StartsWith(term)), JsonRequestBehavior.AllowGet);
        }
       
        //public JsonResult AutoCompleteVeh(string term)
        //{
        //    var result = (from r in con.Vehicles
        //                  where r.Name.ToUpper().Contains(term.ToUpper())
        //                  select new { r.Name }).Distinct();
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}
        
        
        public bool GetPropertyValue(Invoice obj, string property, string value)
        {
            switch (property)
            {
                case "Billty_No":
                    return obj.Billty_No.ToString().Contains(value);
                case "Invoice_No":
                    return obj.Invoice_No.ToString().Contains(value);
                case "Invoice_Date":
                    return obj.Invoice_Date.ToString().Contains(value);
                case "Truck_No":
                    return obj.Truck_No.ToString().Contains(value);
                case "Transport":
                    return obj.Company1.Name.ToString().Contains(value);
                default:
                    return false;
            }
        }

        public ActionResult Invoice(int? id, int? comp)
        {
            con = new Models.SalesConn();
            Branch_id = common.GetBranch_Id(Request);
            Models.Company com = con.Companies.FirstOrDefault(x => x.Id == comp);
            //Models.Invoice _f = id == null ? new Invoice() { Loading_Id = 5, Pan_Card = "0", Royalty_No = "Paid", TDS_Tax = 0, Owner_Name = "N/A", Driver_Name = "N/A", Driver_Address = "N/A", Driver_Licence= "N/A", Truck_No = "", Id = 0, Invoice_Date = DateTime.Now.Date, Company = com, BillType = com.BillType, Company_Id = comp.Value } : con.Invoices.FirstOrDefault(x => x.Id == id);
            
            Models.Invoice _f = id == null ? new Invoice() { Loading_Id = 5, Pan_Card = "", Royalty_No = "Paid", TDS_Tax = null, Owner_Name = "", Driver_Name = "N/A", Driver_Address = "N/A", Driver_Licence = "N/A", Truck_No = "", Id = 0, Invoice_Date = DateTime.Now.Date, Company = com, BillType = com.BillType, Company_Id = comp.Value } : con.Invoices.FirstOrDefault(x => x.Id == id);
            if (id == null)
            {
                var oldInv = con.Invoices.Where(x => x.Company_Id == comp).OrderByDescending(x => x.Invoice_Date).FirstOrDefault();
                if(oldInv !=null)
                    TempData["FormNo"] = oldInv.Form_No ;
            }
                if (ModelState.IsValid)
            {
                if (comp == null)
                {
                    ViewBag.Companies = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Active == true && x.Product_Id == _f.Product_Id).Select(x => new { Name = x.Company1.Name, Id = x.Company1.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
                }
                else
                    ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Id == comp.Value).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");

            ViewBag.Tranporter = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Active == true && x.Company_Id == _f.Company_Id).Select(x => new { Name = x.Company2.Name, Id = x.Company2.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
            ViewBag.Supplier = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Active == true && x.Company_Id == _f.Company_Id).Select(x => new { Name = x.Company.Name, Id = x.Company.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
            ViewBag.Sub_Tranporters = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && (x.Type == 4)).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
            ViewBag.Products = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Company_Id == _f.Company_Id && x.Active == true).Select(x => new { x.Product.Name, x.Product_Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Product_Id", "Name");
            ViewBag.Loadings = new SelectList(con.Loadings.Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
            //Added by raveesh
           // ViewBag.TruckNo = new SelectList(con.Vehicles.Select(x => new { x.Name, x.Id }).ToArray(), "Name", "Name");
            }
            return View(_f);
        }

        public ActionResult Print(int id,bool sign)
        {
            con = new Models.SalesConn();
            Converter.IndiaCurrencyConverter c = new Converter.IndiaCurrencyConverter();
            Models.Invoice _f = con.Invoices.FirstOrDefault(x => x.Id == id);
            ViewBag.ToWord = c.ConvertToWord(Math.Round((_f.Invoice_Amount.Value + _f.VAT_Amount.Value), 0).ToString(), null);
            if (sign == true)
                ViewBag.ShowSign = "Y";
            else
                ViewBag.ShowSign = "N";

            return View(_f ?? new Models.Invoice());
        }

        public ActionResult Bilty(int id)
        {
            con = new Models.SalesConn();
            Models.Invoice _f = con.Invoices.FirstOrDefault(x => x.Id == id);

            Models.Config[] arr = con.Configs.ToArray();

            Models.Taxes tax = new Models.Taxes();
            tax.ServiceTax = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "Service_Tax").Value);
            tax.Education_Cess = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "EC_Tax").Value);
            tax.SHEC = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "HEC_Tax").Value);
            tax.Taxable = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "TAXABLE").Value);

            ViewBag.ServiceTax = tax.ServiceTax;
            //ViewBag.Education_Cess = tax.Education_Cess;
            //ViewBag.SHEC = tax.SHEC;
            //ViewBag.Taxable = tax.Taxable;

            //ViewBag.TaxableAmt = Math.Round(_f.Freight.Value * (tax.Taxable / 100), 2);

            //ViewBag.ServiceTaxAmt = Math.Round(ViewBag.TaxableAmt * (tax.ServiceTax / 100), 2);
            // Applied Due to GST Changes
            ViewBag.ServiceTaxAmt = Math.Round(_f.Freight.Value * (tax.ServiceTax / 100), 2);
            //ViewBag.Education_CessAmt = Math.Round(ViewBag.ServiceTaxAmt * (tax.Education_Cess / 100), 2);
            //ViewBag.SHECAmt = Math.Round(ViewBag.ServiceTaxAmt * (tax.SHEC / 100), 2);
            @ViewBag.TotalFrgAmt = (ViewBag.ServiceTaxAmt + _f.Freight.Value);

            return View(_f ?? new Models.Invoice());
        }

        public ActionResult PaidBilty(int id, bool sign)
        {
            con = new Models.SalesConn();
            Models.Invoice _f = con.Invoices.FirstOrDefault(x => x.Id == id);

            Models.Config[] arr = con.Configs.ToArray();

            Models.Taxes tax = new Models.Taxes();
            tax.ServiceTax = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "Service_Tax").Value);
            tax.Education_Cess = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "EC_Tax").Value);
            tax.SHEC = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "HEC_Tax").Value);
            tax.Taxable = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "TAXABLE").Value);

            ViewBag.ServiceTax = tax.ServiceTax;
            ViewBag.Education_Cess = tax.Education_Cess;
            ViewBag.SHEC = tax.SHEC;
            ViewBag.Taxable = tax.Taxable;

            ViewBag.TaxableAmt = Math.Round(_f.Freight.Value * (tax.Taxable / 100), 2);
            ViewBag.ServiceTaxAmt = Math.Round(ViewBag.TaxableAmt * (tax.ServiceTax / 100), 2);
            ViewBag.Education_CessAmt = Math.Round(ViewBag.ServiceTaxAmt * (tax.Education_Cess / 100), 2);
            ViewBag.SHECAmt = Math.Round(ViewBag.ServiceTaxAmt * (tax.SHEC / 100), 2);
            
            ViewBag.ServiceTaxAmt = Math.Round(_f.Freight.Value * (tax.ServiceTax / 100), 2);
            @ViewBag.TotalFrgAmt = Math.Round( (ViewBag.ServiceTaxAmt + _f.Freight.Value),0);

            if (sign == true)
                ViewBag.ShowSign = "Y";
            else
                ViewBag.ShowSign = "N";


            return View(_f ?? new Models.Invoice());
        }

        public ActionResult Form(int id)
        {
            con = new Models.SalesConn();
            Models.Invoice _f = con.Invoices.FirstOrDefault(x => x.Id == id);
            return View(_f ?? new Models.Invoice());
        }

        [HttpPost]
        public ActionResult Invoice(Models.Invoice I, FormCollection frm)
        {
           
            using (var ts = new System.Transactions.TransactionScope())
            {
                con = new Models.SalesConn(); 
                try
                {
                    Branch_id = common.GetBranch_Id(Request);
                    int transType = 0;
                    Models.Invoice _I = con.Invoices.FirstOrDefault(x => x.Id == I.Id);
                    if (ModelState.IsValid)
                    {
                        if (_I == null)
                        {
                            _I = new Models.Invoice();
                            _I.Billty_No = GetNewBilltyNo(I.Transport_Id);
                            _I.Invoice_No = GetNewInvoiceNo(I.Supplier_Id);
                            //GetNewFormNo(I.Transport_Id);
                            _I.Branch_Id = Branch_id;
                            transType = 1;
                            ViewBag.OpType = "New";
                        }
                        else
                        {
                            transType = 2;
                            ViewBag.OpType = "Old";
                        }

                        _I.Form_No = I.Form_No;
                        _I.Invoice_Date = I.Invoice_Date;
                        _I.Advance = I.Advance;
                        _I.Product_Id = I.Product_Id;
                        _I.Supplier_Id = I.Supplier_Id;
                        _I.Transport_Id = I.Transport_Id;
                        _I.Company_Id = I.Company_Id;
                        _I.Loading_Id = I.Loading_Id;

                        _I.From_City = I.From_City;
                        _I.To_City = I.To_City;
                        _I.Code_1 = I.Code_1;
                        _I.Code_2 = I.Code_2;
                        _I.Truck_No = I.Truck_No;
                        string vehNo = I.Truck_No;
                        _I.Pan_Card = I.Pan_Card;
                        _I.Owner_Name = I.Owner_Name;
                        _I.TDS_Tax = I.TDS_Tax ?? 0;
                        _I.Royalty_No = I.Royalty_No;

                        _I.BillType = I.BillType;
                        _I.Second_Transport_Id = I.Second_Transport_Id ?? 0;
                        _I.Driver_Name = I.Driver_Name ?? "N/A";
                        _I.Driver_Address = I.Driver_Address ?? "N/A";
                        _I.Driver_Licence = I.Driver_Licence ?? "N/A";
                        _I.Remarks = I.Remarks ?? "N/A";
                        _I.Freight_Rate = I.Freight_Rate;
                        _I.Freight = Math.Round((I.Freight_Rate.Value * I.Weight), 0);

                        _I.B_Rate = I.B_Rate;
                        _I.C_Rate = I.C_Rate;
                        _I.Weight = Math.Round(I.Weight, 3);
                        _I.Invoice_Amount = Math.Round((I.B_Rate.Value * I.Weight), 0);

                        _I.VAT_Rate = I.VAT_Rate;
                        _I.VAT_Amount = Math.Round((_I.Invoice_Amount.Value * (I.VAT_Rate.Value / 100)), 0);

                        if (_I.BillType == "To be billed")
                            _I.Deposit_Amount = Math.Round((I.Weight * (I.Code_1.Value * 10)), 0);
                        else
                            _I.Deposit_Amount = Math.Round((I.Weight * (I.Code_2.Value * 10)), 0);

                        string Voucher_No = ("I-" + _I.Id.ToString());
                        Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                        Voucher_No = ("B-" + _I.Id.ToString());
                        Models.Transaction _frieght = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);

                        Models.Vehicle _vehdetail = con.Vehicles.FirstOrDefault(x => x.Name == vehNo);
                        

                        if (_I.Id == 0)
                            con.Invoices.Add(_I);
                        con.SaveChanges();

                        // Saving New Record for Invoice in Trasaction table
                        if (_trans == null)
                            _trans = new Transaction();
                        if (_I.B_Rate != Convert.ToInt32("0"))
                            _trans.Amount1 = Math.Round(((_I.B_Rate.Value * _I.Weight) + _I.VAT_Amount.Value), 0);
                        else
                            _trans.Amount1 = 0;
                        _trans.Amount2 = Math.Round((_I.C_Rate.Value * _I.Weight), 0);
                        _trans.Cr_Account_Id = _I.Supplier_Id;
                        _trans.Dr_Account_Id = _I.Company_Id;
                        _trans.DrCr = "Dr";
                        _trans.Particular = "Sales";
                        _trans.Voucher_Date = _I.Invoice_Date;
                        _trans.Voucher_No = "I-" + _I.Id.ToString();
                        if (_trans.Id == 0)
                            con.Transactions.Add(_trans);

                        // Saving New Record for Invoice in Trasaction table
                        if (_I.BillType == "To be billed")
                        {
                            if (_frieght == null)
                                _frieght = new Transaction();
                            _frieght.Amount1 = Math.Round((_I.Freight_Rate.Value * _I.Weight), 0);
                            _frieght.Cr_Account_Id = _I.Transport_Id;
                            _frieght.Dr_Account_Id = _I.Company_Id;
                            _frieght.DrCr = "Dr";
                            _frieght.Particular = "frieght";
                            _frieght.Voucher_Date = _I.Invoice_Date;
                            _frieght.Voucher_No = "B-" + _I.Id.ToString();
                            if (_frieght.Id == 0)
                                con.Transactions.Add(_frieght);
                        }
                        else if (_frieght != null)
                            con.Transactions.Remove(_frieght);
                        con.SaveChanges();

                        // Saving New Record for Truck Detail in Vehicle table
                        if (_vehdetail == null)
                            _vehdetail = new Vehicle();
                        _vehdetail.Name = _I.Truck_No;
                        _vehdetail.Owner_Name = _I.Owner_Name;
                        _vehdetail.TDS_Tax = _I.TDS_Tax.Value;
                        _vehdetail.Pan_Card = _I.Pan_Card;
                        _vehdetail.Register_Date = _I.Invoice_Date;
                        if (_vehdetail.Id == 0)
                            con.Vehicles.Add(_vehdetail);
                        con.SaveChanges();
                        
                        ts.Complete();
                        if (transType == 1)
                            TempData["message"] = "New Invoice No -" + _I.Invoice_No + " added Succcessfully";
                        else if (transType == 2)
                            TempData["message"] = "Old Invoice No -" + _I.Invoice_No + " updated Succcessfully";
                    }
                    else
                    {
                        ts.Dispose();
                        TempData["message"] = "Please check required field  or cancel  action ";
                        ViewBag.Sub_Tranporters = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && (x.Type == 4)).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                        ViewBag.Products = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Company_Id == I.Company_Id && x.Active == true).Select(x => new { x.Product.Name, x.Product_Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Product_Id", "Name");
                        ViewBag.Loadings = new SelectList(con.Loadings.Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                        ViewBag.Supplier = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Active == true && x.Company_Id == I.Company_Id).Select(x => new { Name = x.Company.Name, Id = x.Company.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
                        ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && (x.Type == 2)).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                        ViewBag.Tranporter = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Active == true && x.Company_Id == I.Company_Id).Select(x => new { Name = x.Company2.Name, Id = x.Company2.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
                        return View(I);
                    }
                    return RedirectToAction("Index", "invoices", new { comp = _I.Company_Id });
                }
                catch (Exception e)
                {
                    ts.Dispose();
                    ViewBag.Sub_Tranporters = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && (x.Type == 4)).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                    ViewBag.Products = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Company_Id == I.Company_Id && x.Active == true).Select(x => new { x.Product.Name, x.Product_Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Product_Id", "Name");
                    ViewBag.Loadings = new SelectList(con.Loadings.Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                    ViewBag.Supplier = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Active == true && x.Company_Id == I.Company_Id).Select(x => new { Name = x.Company.Name, Id = x.Company.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
                    ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && (x.Type == 2)).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                    ViewBag.Tranporter = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id > 0 && x.Branch_Id == Branch_id && x.Active == true && x.Company_Id == I.Company_Id).Select(x => new { Name = x.Company2.Name, Id = x.Company2.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
                    return View(I);
                }
            }
        }

        public ActionResult Delete(int Id)
        {
            
            using (var ts = new System.Transactions.TransactionScope())
            {

                con = new Models.SalesConn();
                try
                {
                    Models.Invoice _I = con.Invoices.FirstOrDefault(x => x.Id == Id);
                    if (_I != null)
                        con.Invoices.Remove(_I);

                    string Voucher_No = ("I-" + _I.Id.ToString());
                    Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                    if (_trans != null)
                        con.Transactions.Remove(_trans);

                    Voucher_No = ("B-" + _I.Id.ToString());
                    Transaction _frieght = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                    if (_frieght != null)
                        con.Transactions.Remove(_frieght);

                    con.SaveChanges();
                    ts.Complete();
                    TempData["message"] = "Invoice Deleted Succcessfully";
                    return RedirectToAction("Index", "invoices", new { comp = _I.Company_Id });
                }
                catch (Exception e)
                {
                    ts.Dispose();
                    return RedirectToAction("Index");
                    //return View();
                }
            }
        }

        public JsonResult SelectCompany(int? product_id, int? company_id, int? transport_Id, int? supplier_Id)
        {
            con = new Models.SalesConn();
            Branch_id = common.GetBranch_Id(Request);
            decimal vatrate = Convert.ToDecimal(con.Configs.FirstOrDefault(x => x.Variable == "VAT_Rate").Value);
            decimal other_vatrate = Convert.ToDecimal(con.Configs.FirstOrDefault(x => x.Variable == "Other_VAT_Rate").Value);

            Models.Invoice_Rates rate = con.Invoice_Rates.FirstOrDefault(x => x.Branch_Id == Branch_id && x.Product_Id == product_id && x.Company_Id == company_id && x.Transport_Id > 0 && (transport_Id == null ? true : x.Transport_Id == transport_Id) && (supplier_Id == null ? true : x.Supplier_Id == supplier_Id));
            if (rate == null)
            { return Json(new { status = "Error", msg = "Sorry ,Invoice Rate is not entered in master detail !" }, JsonRequestBehavior.AllowGet); }
            Models.Freight f = con.Freights.FirstOrDefault(x => x.Branch_Id == Branch_id && x.From_Place == rate.Company.City && x.To_Place == rate.Company1.City);
            if (f == null)
            { return Json(new { status = "Error", msg = "Sorry ,Please fill Freight Rate first for selected places it is missing !" }, JsonRequestBehavior.AllowGet); }
            var temp = new { status = "Success", msg = "", rate.B_Rate, rate.C_Rate, Supplier_Id = rate.Supplier_Id, Transport_Id = rate.Transport_Id, From = rate.Company.City, To = rate.Company1.City, FrieghtRate = f.Rate, VAT = (rate.Company.State.ToUpper().Trim() == rate.Company1.State.ToUpper().Trim() ? vatrate : other_vatrate), Company_Id = rate.Company1.Id, Freigt = f.Id };
            return Json(temp, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SelectPreStatus(string truck_no)
        {
            con = new Models.SalesConn();
            if (truck_no != null)
            {
                Models.Vehicle delsta = con.Vehicles.FirstOrDefault(x => x.Name == truck_no);
                if (delsta == null)
                { 
                    return Json(new { status = "Error", msg = "Please mention the Pan Card No,Owner name,TDS Tax Rate !" }, JsonRequestBehavior.AllowGet); 
                }
                else 
                {
                    var vehrelated = new { status = "Success", msg = "", delsta.Pan_Card, delsta.Owner_Name, delsta.TDS_Tax };
                    return Json(vehrelated, JsonRequestBehavior.AllowGet);
                }
            }
            else
            { 
                return Json(new { status = "Error", msg = "Blank Truck No is not allowed" }, JsonRequestBehavior.AllowGet); 
            }
        }

        public ActionResult GetList(string query)
        {
            con = new Models.SalesConn();
            query = query.Replace(" ", "");
            if (query.Length > 1)
            {
                int op = query.LastIndexOf(",");
                query = query.Substring(op + 1);
            }
            var users = (from u in con.Invoices
                         where u.Truck_No.Contains(query)
                         orderby u.Truck_No // optional
                         select u.Truck_No).Distinct().ToArray();

            return Json(users, JsonRequestBehavior.AllowGet);
        }

        public int GetNewInvoiceNo(int Supplier_Id)
        {
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }

            var l = con.Invoices.Where(x => (x.Invoice_Date >= dfrom.Value && x.Invoice_Date <= dto.Value) && x.Supplier_Id == Supplier_Id).OrderByDescending(x => x.Invoice_No).FirstOrDefault();
            return l == null ? 1 : (l.Invoice_No + 1);
        }

        public int GetNewBilltyNo(int Transport_Id)
        {
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }
            var l = con.Invoices.Where(x => (x.Invoice_Date >= dfrom.Value && x.Invoice_Date <= dto.Value) && x.Transport_Id == Transport_Id).OrderByDescending(x => x.Billty_No).FirstOrDefault();
            return l == null ? 1 : (l.Billty_No + 1);
        }

        public int GetNewFormNo(int Transport_Id)
        {
            var l = con.Invoices.Where(x => x.Transport_Id == Transport_Id).OrderByDescending(x => x.Form_No).FirstOrDefault();
            return l == null ? 1 : (l.Form_No + 1);
        }

    }
}
