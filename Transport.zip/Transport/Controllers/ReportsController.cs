﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Data.Objects.SqlClient;
using System.Text.RegularExpressions;
using System.Globalization;

namespace Transport.Controllers
{
    public class ReportsController : Controller
    {
       
        Models.SalesConn con;
        SelectListItem[] arr = new SelectListItem[] { new SelectListItem() { Text = "To Pay", Value = "To Pay" }, new SelectListItem() { Text = "To be billed", Value = "To be billed" }};
 
        #region Payment Entry Code

        public ActionResult frieght_payment_entry(int? comp, string bilty="To Pay") {
            int Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            var transports  = con.Companies.Where(x => x.Id > 0 && x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 3).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name);
            ViewBag.Companies = new SelectList(transports, "Id", "Name", comp);
            int transport_id = comp == null ? transports.FirstOrDefault().Id : comp.Value;
            Models.Invoice[] Arr = con.Invoices.Where(x => x.Paid_Amount == null && x.BillType == bilty && x.Transport_Id == transport_id).ToArray();
            ViewBag.Bilty = new SelectList(arr,"Value","Text", bilty);
            return View(Arr);
        }

        [HttpPost]
        public ActionResult frieght_payment_entry(FormCollection frm)
        {
           int Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            var transports = con.Companies.Where(x => x.Id > 0 && x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 3).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name);
            ViewBag.Companies = new SelectList(transports, "Id", "Name", frm["ddlcomp"]);
            int transport_id =Convert.ToInt32(frm["ddlcomp"]);
            string bilty = frm["bilty"];

            foreach (var item in frm.AllKeys.Where(x=> x.Contains("Paid")))
            {
                int inv_id = Convert.ToInt32(item.Split('_')[1]);
                Models.Invoice inv = con.Invoices.FirstOrDefault(x=> x.Id== inv_id);
                inv.Paid_Amount = Convert.ToDecimal(frm[item]);
                inv.Paid_Date = DateTime.Now;
                if (inv.Owner_Name == null)
                    inv.Owner_Name = "N/A";
                if (inv.TDS_Tax== null)
                    inv.TDS_Tax = 0;
                if (inv.Pan_Card == null)
                    inv.Pan_Card = "N/A"; 
                con.SaveChanges();
            }

            Models.Invoice[] Arr = con.Invoices.Where(x => x.Paid_Amount == null && x.BillType == bilty && x.Transport_Id == transport_id).ToArray();
            ViewBag.Bilty = new SelectList(arr, "Value", "Text", bilty);
            return View(Arr);
        }

        #endregion

        
        #region Form Code

        public ActionResult supplier_accounts(int? Branch_id_pass)
        {
            Transport.Models.User usr = null;
            var cookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            var decrypted = FormsAuthentication.Decrypt(cookie.Value);
            if (!string.IsNullOrEmpty(decrypted.UserData))
            {
                usr = JsonConvert.DeserializeObject<Transport.Models.User>(decrypted.UserData);
            }
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = new Models.Account_Report();
            int Branch_id = common.GetBranch_Id(Request);
            //int cmon = DateTime.Now.Month;
            //if (cmon < 4)
            //    frm.From_Date = new DateTime(DateTime.Now.Year - 1, 4, 1);
            //else
            //    frm.From_Date = new DateTime(DateTime.Now.Year, 4, 1);
            frm.From_Date = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            frm.To_Date = DateTime.Now.Date;

            if (ModelState.IsValid)
            {

                ViewBag.Branch = new SelectList(usr.User_Branches.Select(x => new { Id = x.Branch.Id, Name = x.Branch.Name }), "Id", "Name",Branch_id);
                ViewBag.Companies = new SelectList(con.Companies.Where(x => (Branch_id == null ? true : x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0) && x.Status == true && x.Type == 1).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
                ViewBag.Receipant = new SelectList(con.Companies.Where(x => (Branch_id == null ? true : x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0) && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
                ViewBag.Product = new SelectList(con.Products.Where(x => (Branch_id == null ? true : x.Product_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0) && x.Active == true).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
                ViewBag.SubTranport = new SelectList(con.Companies.Where(x => (Branch_id == null ? true : x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0) && x.Status == true && x.Type == 4).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            }
            return View(frm);
        }

        public ActionResult tranports_accounts(int? Branch_id)
        {
            Transport.Models.User usr = null;
            var cookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            var decrypted = FormsAuthentication.Decrypt(cookie.Value);
            if (!string.IsNullOrEmpty(decrypted.UserData))
            {
                usr = JsonConvert.DeserializeObject<Transport.Models.User>(decrypted.UserData);
            }

            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = new Models.Account_Report();
            if (ModelState.IsValid)
            {
                //int cmon = DateTime.Now.Month;
                //if (cmon < 4)
                //    frm.From_Date = new DateTime(DateTime.Now.Year - 1, 4, 1);
                //else
                //    frm.From_Date = new DateTime(DateTime.Now.Year, 4, 1);
                frm.From_Date = new DateTime(DateTime.Now.Year , DateTime.Now.Month, 1);
                frm.To_Date = DateTime.Now.Date;
                ViewBag.BranchName = new SelectList(usr.User_Branches.Select(x => new { Id = x.Branch.Id, Name = x.Branch.Name }), "Id", "Name");
                ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Id > 0 && (Branch_id == null ? true : x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0) && x.Status == true && x.Type == 3).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
                ViewBag.Receipant = new SelectList(con.Companies.Where(x => (Branch_id == null ? true : x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0) && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
                ViewBag.Secondary = new SelectList(con.Companies.Where(x => (Branch_id == null ? true : x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0) && x.Status == true && x.Type == 4).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            }
            return View(frm);
        }

        [HttpPost]
        public ActionResult tranports_accounts(Transport.Models.Account_Report frm, FormCollection col)
        {
            if (frm.ReportType < 4 )
            {
                frm.From_Date = Convert.ToDateTime(col["AFrom_Date"]);
                frm.To_Date = Convert.ToDateTime(col["ATo_Date"]);
            }

            if (frm.ReportType > 100 )
            {
                frm.From_Date = Convert.ToDateTime(col["AFrom_Date"]);
                frm.To_Date = Convert.ToDateTime(col["ATo_Date"]);
            }
            if (frm.ReportType > 30 && frm.ReportType < 35)
            {
                frm.From_Date = Convert.ToDateTime(col["AFrom_Date"]);
                frm.To_Date = Convert.ToDateTime(col["ATo_Date"]);
            }
            TempData["frm"] = frm;

            switch (frm.ReportType)
            {
                case 1:
                    return RedirectToAction("Sales");
                case 2:
                    return RedirectToAction("Bank");
                case 211:
                    return RedirectToAction("RebateDetail");
                case 3:
                    return RedirectToAction("AccountView");
                case 101:
                    return RedirectToAction("TSales");
                case 201:
                    return RedirectToAction("TBank");
                case 301:
                    return RedirectToAction("TAccountView");
                case 302:
                    return RedirectToAction("TAccountSummary", new { type = "OpBal" });
                case 401:
                    return RedirectToAction("TRebate");
                case 4:
                    return RedirectToAction("supply_detail"); // Supplier Transaction Detail
                case 5:
                    return RedirectToAction("sale_detail"); // Supplier Sale Detail
                case 6:
                    return RedirectToAction("sales_turnover_detail");
                case 7:
                    return RedirectToAction("purchase_detail"); // Loading Status Detail
                case 8:
                    switch (col["GroupBy"])
	                {
                        case "0":
                            return RedirectToAction("supply_summary", new { group = "none" });
                        case "1":
                            return RedirectToAction("supply_summary", new { group = "supmat" });
                        case "2":
                            return RedirectToAction("supply_summary", new { group = "supmatrec" });
                        case "3":
                            return RedirectToAction("supply_summary", new { group = "suprec" });
                        case "4":
                            return RedirectToAction("supply_summary", new { group = "suprecmat" });
                        default:
                            return View();
	                }
                case 11:
                    switch (col["GroupBy"])
                    {
                        case "0":
                            return RedirectToAction("sales_summary", new { group = "none" });
                        case "1":
                            return RedirectToAction("sales_summary", new { group = "supmat" });
                        case "2":
                            return RedirectToAction("sales_summary", new { group = "supmatrec" });
                        case "3":
                            return RedirectToAction("sales_summary", new { group = "suprec" });
                        case "4":
                            return RedirectToAction("sales_summary", new { group = "suprecmat" });
                        default:
                            return View();
                    } 
                case 12:
                    return RedirectToAction("purchase_detail");
                case 13:
                    return RedirectToAction("loading_details_nonbilty");
                case 20:
                    return RedirectToAction("transaction_record");  //transaction_record
                case 21:
                    return RedirectToAction("transaction_detail");  //transaction_detail
                case 22:
                    switch (col["TurnoverBy"])
                    {
                        case "0":
                            return RedirectToAction("freight_turnover", new { bilty = "both" });
                        case "1":
                            return RedirectToAction("freight_turnover", new { bilty = "To be Billed" });
                        case "2":
                            return RedirectToAction("freight_turnover", new { bilty = "To Pay" });
                        default:
                            return View();
                    }
                case 25:
                    return RedirectToAction("freight_paidover");
                case 28:
                    return RedirectToAction("freight_status");
                case 26:
                    return RedirectToAction("loading_details");
                case 27: 
                    switch (col["paidBy"] )  
                    {
                        case "0": // Paid Option
                            if (col["orderBy"] == "0")   // To Be billed only
                            {
                                if (col["TurnoverBy"]=="0")
                                    return RedirectToAction("tptbb_paid_detail", new { paystatus = "Paid Only",orderStatus="Invoice_Date", billType="Both" });
                                else if (col["TurnoverBy"]=="1")
                                    return RedirectToAction("tptbb_paid_detail", new { paystatus = "Paid Only",orderStatus="Invoice_Date", billType="To be billed" });
                                else 
                                    return RedirectToAction("tptbb_paid_detail", new { paystatus = "Paid Only", orderStatus = "Invoice_Date", billType = "To Pay" });
                            }
                            else
                            {
                                if (col["TurnoverBy"] == "0")
                                    return RedirectToAction("tptbb_paid_detail", new { paystatus = "Paid Only", orderStatus = "Paid_Date", billType = "Both" });
                                else if (col["TurnoverBy"] == "1")
                                    return RedirectToAction("tptbb_paid_detail", new { paystatus = "Paid Only", orderStatus = "Paid_Date", billType = "To be billed" });
                                else
                                    return RedirectToAction("tptbb_paid_detail", new { paystatus = "Paid Only", orderStatus = "Paid_Date", billType = "To Pay" });
                            }
                        case "1": // Not Paid Option
                            if (col["orderBy"] == "0") // To pay only
                            {
                                if (col["TurnoverBy"] == "0")
                                    return RedirectToAction("tptbb_notpaid_detail", new { paystatus = "Not Paid Only", orderStatus = "Invoice_Date", billType = "Both" });
                                else if (col["TurnoverBy"] == "1")
                                        return RedirectToAction("tptbb_notpaid_detail", new { paystatus = "Not Paid Only", orderStatus = "Invoice_Date", billType = "To be billed" });
                                else
                                    return RedirectToAction("tptbb_notpaid_detail", new { paystatus = "Not Paid Only", orderStatus = "Invoice_Date", billType = "To Pay" });
                            }
                            else
                            {
                                if (col["TurnoverBy"] == "0")
                                    return RedirectToAction("tptbb_notpaid_detail", new { paystatus = "Not Paid Only", orderStatus = "Paid_Date", billType = "Both" });
                                else if (col["TurnoverBy"] == "1")
                                    return RedirectToAction("tptbb_notpaid_detail", new { paystatus = "Not Paid Only", orderStatus = "Paid_Date", billType = "To be billed" });
                                else
                                    return RedirectToAction("tptbb_notpaid_detail", new { paystatus = "Not Paid Only", orderStatus = "Paid_Date", billType = "To Pay" });
                            }
                        default:
                            return View();
                    }
                //case 27:
                //    return RedirectToAction("notpaid", new { bilty = "To be Billed" });
                //case 28:
                //    return RedirectToAction("notpaid", new { bilty = "To Pay" });
                case 29:                    
                    switch (col["GroupBy"])
                    {
                        case "0":
                            return RedirectToAction("total_freight_summary", new { group = "none" });
                        case "1":
                            return RedirectToAction("total_freight_summary", new { group = "transmat" });
                        case "2":
                            return RedirectToAction("total_freight_summary", new { group = "transrec" });
                        default:
                            return View();
                    }
                case 30:
                    return RedirectToAction("TDSSummary");
                case 31:
                    return RedirectToAction("AccountSummary", new  { type="OpBal"});
                case 32:
                    return RedirectToAction("AccountSummary", new { type = "Cash" });
                case 33:
                    return RedirectToAction("AccountSummary", new { type="Rebate"});
                case 34:
                    return RedirectToAction("AccountSummary", new { type = "Ledger" });
                default:
                    return View(frm);
            }
        }

        #endregion


        #region Transport Reports

        // Sales Statement Report (Transport Account)
        public ActionResult TSales()
        {
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            con = new Models.SalesConn();
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";

            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                && x.Cr_Account_Id == frm.Cr_Account_Id
                && (x.Voucher_Date >= frm.From_Date
                && x.Voucher_Date <= frm.To_Date
                && (x.Particular == "frieght"))).ToArray().Where(x => TRate(ref x)).OrderBy(x => x.Voucher_Date); 
            //return View(data.Where(x => TRate(ref x)));

            return View(data);
        }

        // Bank Statement Report (Transport Account)
        public ActionResult TBank()
        {
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            con = new Models.SalesConn();
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id) 
                && x.Cr_Account_Id == frm.Cr_Account_Id 
                && (x.Voucher_Date >= frm.From_Date 
                && x.Voucher_Date <= frm.To_Date
                && (x.Particular.Contains("Reciept") || x.Particular.Contains("Discount") || x.Particular.Contains("Rebate")))).ToArray().OrderBy(x => x.Voucher_Date);
            return View(data.Where(x => TRate(ref x)));
        }

        // Bank Statement Report (Transport Account)
        public ActionResult TRebate()
        {
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            con = new Models.SalesConn();
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                && x.Cr_Account_Id == frm.Cr_Account_Id
                && (x.Voucher_Date >= frm.From_Date
                && x.Voucher_Date <= frm.To_Date
                && (x.Particular.Contains("Discount") || x.Particular.Contains("Rebate")))).ToArray().OrderBy(x => x.Voucher_Date);
            return View(data.Where(x => TRate(ref x)));
        }

        // Account Statement Report (Transport Account Statement)
        public ActionResult TAccountView()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            decimal opening = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id) && x.Cr_Account_Id == frm.Cr_Account_Id && (x.Particular == "Opening Balance" || x.Voucher_Date < frm.From_Date)).ToArray().Sum(x => (x.DrCr == "Cr" ? -1 * x.Amount1 : x.Amount1));
            
            IList<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                && (x.Cr_Account_Id == frm.Cr_Account_Id)
                && (x.Particular != "Opening Balance")
                && (x.Voucher_Date >= frm.From_Date
                && x.Voucher_Date <= frm.To_Date)).OrderBy(x => x.Voucher_Date).ToList().Where(x => TRate(ref x)).ToList(); ;

            Models.Transaction op = new Models.Transaction() { Particular = "Opening Balance", DrCr = opening < 0 ? "Cr" : "Dr", Amount1 = opening > 0 ? opening : -1 * opening, Voucher_Date = frm.From_Date };
            data.Insert(0, op);
            return View(data);
        }

        // New added Account Summary Report
        public ActionResult TAccountSummary()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";

            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.RepType = Request["type"];
            string reptype = Request["type"];

            DateTime startdate = DateTime.ParseExact("01/04/2015", "dd/MM/yyyy", CultureInfo.InvariantCulture);

            if (reptype == "OpBal")
            {
                //IEnumerable<Models.Transaction> data = con.Transactions.Join(con.Invoices, x => Regex.Match(x.Voucher_No , @"\d+").Value , y => y.Id, (x, y) => new { x.}).Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                //    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                //    && (x.Voucher_Date > startdate && x.Voucher_Date <= frm.To_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList();

                // commneted: 04/06/2017  :Raveesh
                //if (ViewBag.RateBy == "All")
                //{
                    IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                        && (x.Cr_Account_Id == frm.Cr_Account_Id)
                        && (x.Voucher_Date <= frm.From_Date)).ToList();
                    return View(data);
                //}
                //else
                //{
                //    IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                //        && (x.Cr_Account_Id == frm.Cr_Account_Id)
                //        && (x.Voucher_Date >= startdate && x.Voucher_Date < frm.From_Date)).ToList();
                //    return View(data);
                //}
            }
            else if (reptype == "Cash")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                    && (x.Particular == "Reciept")
                    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                    && (x.Voucher_Date >= frm.From_Date
                    && x.Voucher_Date <= frm.To_Date)).ToList();
                return View(data);
            }
            else if (reptype == "Rebate")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                    && (x.Particular == "Rebate" || x.Particular == "Discount")
                    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                    && (x.Voucher_Date >= frm.From_Date
                    && x.Voucher_Date <= frm.To_Date)).ToList();
                return View(data);
            }
            else if (reptype == "Ledger")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                    && (x.Voucher_Date >= startdate)
                    && (x.Voucher_Date <= frm.To_Date)).ToList();
                return View(data);
            }
            return View();
        }

        public ActionResult transaction_record()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id> 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }

        public ActionResult transaction_detail()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();
            return View(data);
        }

        public ActionResult freight_turnover()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            string bilty = Request["bilty"];

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (bilty=="both"? true: x.BillType==bilty) && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }

        public ActionResult freight_status()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

           // string bilty = Request["bilty"];

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }

        public ActionResult freight_paidover()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id) 
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }

        public ActionResult loading_details()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;
            //x => x.Transport_Id >= 0 &&
            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                //&& (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }
        public ActionResult loading_details_nonbilty()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;
            //x.Transport_Id >= 0 &&
            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Supplier_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }




        public ActionResult tptbb_paid_detail()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;
            
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";

            if (frm.Sec_Tranport_Id != null)
                ViewBag.ttype = con.Companies.Where(x => x.Type == 4).FirstOrDefault(x => x.Id == frm.Sec_Tranport_Id).Name;
            else
                ViewBag.ttype = "ALL";

            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.bType = Request["billType"];
            ViewBag.pType = Request["paystatus"];
            
            ViewBag.bType=(ViewBag.bType == "Both" ? "To be billed/TP Detail" : Request["billType"]);
            string pstatus = Request["paystatus"];
            string ostatus = Request["orderstatus"];
            string billtype = Request["billType"];

            if (ostatus == "Invoice_Date")   
            {
                IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                    && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                    && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                    && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)
                    && (billtype == "Both" ? true : x.BillType == billtype) 
                    && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                    && (x.Paid_Date != null)).OrderBy(x => x.Invoice_Date).ToArray();
                return View(data);
            }
            else
            {
                IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Paid_Date >= frm.From_Date && x.Paid_Date <= frm.To_Date
                    && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                    && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                    && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)
                    && (billtype == "Both" ? true : x.BillType == billtype)
                    && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                    && (x.Paid_Date != null)).OrderBy(x => x.Invoice_Date).ToArray();
                return View(data);
            }
        }

        public ActionResult tptbb_notpaid_detail()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";

            if (frm.Sec_Tranport_Id != null)
                ViewBag.ttype = con.Companies.Where(x => x.Type == 4).FirstOrDefault(x => x.Id == frm.Sec_Tranport_Id).Name;
            else
                ViewBag.ttype = "ALL";

            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            ViewBag.bType = Request["billType"];
            ViewBag.pType = Request["paystatus"];
            ViewBag.ttype = frm.Sec_Tranport_Id == null ? "ALL" : con.Companies.Where(x => x.Type == 4).FirstOrDefault(x => x.Id == frm.Sec_Tranport_Id).Name;

            string billtype = Request["billType"];
            string pstatus = Request["paystatus"];
 
                IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                    && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                    && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                    && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                    && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)
                    && (billtype == "Both" ? true : x.BillType == billtype)
                    && (x.Paid_Date == null)).OrderBy(x => x.Invoice_Date).ToArray();
                return View(data);
        }

        public ActionResult total_freight_summary()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Transport_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();
            return View(data);
        }

        public ActionResult TDSSummary()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Transport_Id > 0 && x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }

        #endregion

        #region Supplier Report

        public ActionResult Sales()
        {
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            con = new Models.SalesConn();
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";

            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            if (frm.RateBy==0)
                ViewBag.RateBy = "Bill Rate";
            else
                ViewBag.RateBy = "Cash Rate";

            IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id) 
                && x.Cr_Account_Id == frm.Cr_Account_Id 
                && (x.Voucher_Date >= frm.From_Date 
                && x.Voucher_Date <= frm.To_Date 
                && (x.Particular == "Sales" || x.Particular == "frieght"))).ToArray().Where(x => Rate(ref x, frm.RateBy)).OrderBy(x => x.Voucher_Date);
            return View(data);

            //IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id) && x.Cr_Account_Id == frm.Cr_Account_Id && (x.Voucher_Date >= frm.From_Date && x.Voucher_Date <= frm.To_Date && (x.Particular != "Opening Balance") && (x.Particular == "Sales"))).ToArray().Where(x => Rate(ref x, frm.RateBy)).OrderBy(x => x.Voucher_Date);
            //return View(data.Where(x => Rate(ref x, frm.RateBy)));
        }

        public ActionResult Bank()
        {
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            con = new Models.SalesConn();
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;

            if (frm.RateBy == 0)
                ViewBag.RateBy = "Bill Rate";
            else
                ViewBag.RateBy = "Cash Rate";

            IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)  
                && x.Cr_Account_Id == frm.Cr_Account_Id 
                && (x.Voucher_Date >= frm.From_Date 
                && x.Voucher_Date <= frm.To_Date)
                && (x.Particular.Contains("Reciept"))).ToArray().OrderBy(x => x.Voucher_Date);
            return View(data.Where(x => StateRate(ref x, frm.RateBy)));
        }
        //|| x.Particular.Contains("Discount") || x.Particular.Contains("Rebate")

        public ActionResult RebateDetail()
        {
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            con = new Models.SalesConn();
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;


            IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                && x.Cr_Account_Id == frm.Cr_Account_Id
                && (x.Voucher_Date >= frm.From_Date
                && x.Voucher_Date <= frm.To_Date)
                && (x.Particular.Contains("Discount") || x.Particular.Contains("Rebate"))).ToArray().OrderBy(x => x.Voucher_Date);
            return View(data.Where(x => Rate(ref x, frm.RateBy)));
        }


        // Account Statement Report (Html)
        public ActionResult AccountView()
        {
            int cyear = DateTime.Now.Year;
            int cmon = DateTime.Now.Month;

            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");

            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;

            if (frm.RateBy == 0)
                ViewBag.RateBy = "";
            else
                ViewBag.RateBy = "Cash Rate";
            //&& x.Amount1>0

            decimal opening = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id) && (x.Cr_Account_Id == frm.Cr_Account_Id) && (x.Particular == "Opening Balance" || x.Voucher_Date < frm.From_Date)).ToArray().Where(x => Rate(ref x, frm.RateBy) ).Sum(x => (x.DrCr == "Cr" ? -1 * x.Amount1 : x.Amount1));
            IList<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                && x.Cr_Account_Id == frm.Cr_Account_Id
                && x.Particular != "Opening Balance"
                && (x.Voucher_Date >= frm.From_Date
                && x.Voucher_Date <= frm.To_Date)).OrderBy(x => x.Voucher_Date).ToList().Where(x => Rate(ref x, frm.RateBy)).ToList();

            Models.Transaction op = new Models.Transaction() { Particular = "Opening Balance", DrCr = opening < 0 ? "Cr" : "Dr", Amount1 = opening > 0 ? opening : -1 * opening, Voucher_Date = frm.From_Date };
            data.Insert(0, op);
            return View(data);
        }

        // Account Statement Report (Excel)
        public ActionResult Accounts()
        {

            Response.ClearContent();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment; filename=Accounts.xls");
            Response.ContentType = "application/ms-excel";
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];

            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.RateBy = frm.RateBy;

            decimal opening = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id) && x.Cr_Account_Id == frm.Cr_Account_Id && (x.Particular == "Opening Balance" || x.Voucher_Date < frm.From_Date)).ToArray().Where(x => Rate(ref x, frm.RateBy)).Sum(x => (x.DrCr == "Cr" ? -1 * x.Amount1 : x.Amount1));
            IList<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id) && x.Cr_Account_Id == frm.Cr_Account_Id && x.Particular != "Opening Balance" && (x.Voucher_Date >= frm.From_Date && x.Voucher_Date <= frm.To_Date)).OrderBy(x => x.Voucher_Date).ToList().Where(x => Rate(ref x, frm.RateBy)).ToList();
            Models.Transaction op = new Models.Transaction() { Particular = "Opening Balance", DrCr = opening < 0 ? "Cr" : "Dr", Amount1 = opening > 0 ? opening : -1 * opening, Voucher_Date = frm.From_Date };
            data.Insert(0, op);

            return View(data.Where(x => Rate(ref x, frm.RateBy)));
        }

        // New added Account Summary Report
        public ActionResult AccountSummary()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.RepType = Request["type"];
            if (frm.RateBy < 0)
                ViewBag.RateBy = "All";
            else if (frm.RateBy == 0)
                ViewBag.RateBy = "Bill Rate";
            else
                ViewBag.RateBy = "Cash Rate";

            string reptype=Request["type"];

            //DateTime startdate = DateTime.ParseExact("2015-03-31", "yyyy-mm-dd ", System.Globalization.CultureInfo.InvariantCulture);
            DateTime startdate = DateTime.ParseExact("01/04/2015", "dd/MM/yyyy", CultureInfo.InvariantCulture);

            if (reptype == "OpBal")
            {
                //IEnumerable<Models.Transaction> data = con.Transactions.Join(con.Invoices, x => Regex.Match(x.Voucher_No , @"\d+").Value , y => y.Id, (x, y) => new { x.}).Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                //    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                //    && (x.Voucher_Date > startdate && x.Voucher_Date <= frm.To_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList();

                if (ViewBag.RateBy == "All")
                {
                    IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                        && (x.Cr_Account_Id == frm.Cr_Account_Id)
                        && (x.Voucher_Date <= frm.From_Date)).ToList();
                    return View(data);
                }
                else
                {
                    IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                        && (x.Cr_Account_Id == frm.Cr_Account_Id)
                        && (x.Voucher_Date <= frm.From_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList();
                    return View(data);
                }
            }
            else if (reptype == "Cash")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id )
                    && (x.Particular == "Reciept") 
                    && (x.Cr_Account_Id == frm.Cr_Account_Id) 
                    && (x.Voucher_Date >= frm.From_Date 
                    && x.Voucher_Date <= frm.To_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList();
                return View(data);
            }
            else if (reptype == "Rebate")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id) 
                    && (x.Particular == "Rebate" || x.Particular == "Discount") 
                    && (x.Cr_Account_Id == frm.Cr_Account_Id) 
                    && (x.Voucher_Date >= frm.From_Date 
                    && x.Voucher_Date <= frm.To_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList();
                return View(data);
            }
            else if (reptype == "Ledger")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                    && (x.Voucher_Date >= startdate)
                    && (x.Voucher_Date <= frm.To_Date)).ToList().Where(x => RateAcc(ref x, frm.RateBy)).ToList();
                return View(data);
            }
            return View();
        }

        // New added Account Summary Report
        public ActionResult AccountSummaryAll()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd/MMM/yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.RepType = Request["type"];
            if (frm.RateBy < 0)
                ViewBag.RateBy = "All";
            else if (frm.RateBy == 1)
                ViewBag.RateBy = "Bill Rate";
            else
                ViewBag.RateBy = "Cash Rate";

            string reptype = Request["type"];

            //DateTime startdate = DateTime.ParseExact("2015-03-31", "yyyy-mm-dd ", System.Globalization.CultureInfo.InvariantCulture);
            DateTime startdate = DateTime.ParseExact("01/04/2015", "dd/MM/yyyy", CultureInfo.InvariantCulture);

            if (reptype == "OpBal")
            {
                //IEnumerable<Models.Transaction> data = con.Transactions.Join(con.Invoices, x => Regex.Match(x.Voucher_No , @"\d+").Value , y => y.Id, (x, y) => new { x.}).Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                //    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                //    && (x.Voucher_Date > startdate && x.Voucher_Date <= frm.To_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList();

                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                    && (x.Cr_Account_Id == frm.Cr_Account_Id) && (x.Voucher_Date >= startdate && x.Voucher_Date < frm.From_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList(); 
                return View(data);
            }
            else if (reptype == "Cash")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                    && (x.Particular == "Reciept")
                    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                    && (x.Voucher_Date >= frm.From_Date
                    && x.Voucher_Date <= frm.To_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList();
                return View(data);
            }
            else if (reptype == "Rebate")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                    && (x.Particular == "Rebate" || x.Particular == "Discount")
                    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                    && (x.Voucher_Date >= frm.From_Date
                    && x.Voucher_Date <= frm.To_Date)).ToList().Where(x => Rate1(ref x, frm.RateBy)).ToList();
                return View(data);
            }
            else if (reptype == "Ledger")
            {
                IEnumerable<Models.Transaction> data = con.Transactions.Where(x => (frm.Dr_Account_Id == null ? true : x.Dr_Account_Id == frm.Dr_Account_Id)
                    && (x.Cr_Account_Id == frm.Cr_Account_Id)
                    && (x.Voucher_Date >= startdate)
                    && (x.Voucher_Date <= frm.To_Date)).ToList().Where(x => RateAcc(ref x, frm.RateBy)).ToList();
                return View(data);
            }
            return View();
        }

        // Supplier  Transaction Detail Report (Supplier)
        public ActionResult supply_detail()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id== frm.Branch_Id).Name;

            ViewBag.From_Party =frm.Cr_Account_Id==null ? "ALL": con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Supplier_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Product_Id == null ? true : x.Product_Id == frm.Product_Id)
                && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();
            return View(data);
        }

        // Supplier Detail Report (Account)
        public ActionResult sale_detail()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            ViewBag.RateBy = frm.RateBy;
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
                ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Supplier_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Product_Id == null ? true : x.Product_Id == frm.Product_Id)
                && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            //return View(data.Where(x => Calc(ref x, frm.RateBy)));
            return View(data);
        }

        // Sales Turnover Detail (Supplier Report)      
        public ActionResult sales_turnover_detail()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            ViewBag.RateApplied = frm.RateBy.ToString();
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.RateApplied = frm.RateBy.ToString();
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;
            
            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Supplier_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Product_Id == null ? true : x.Product_Id == frm.Product_Id)
                && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();
            if (frm.RateBy==0)
                return View(data);
            else
                return View(data.Where(x=> Calc(ref x,frm.RateBy)));
        }
        
        //Dispatch Detail
        public ActionResult purchase_detail()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Supplier_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Product_Id == null ? true : x.Product_Id == frm.Product_Id)
                && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }

        // Material Delievery Report (Working Name of Report)
        public ActionResult supply_summary()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Supplier_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Product_Id == null ? true : x.Product_Id == frm.Product_Id)
                && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray().OrderBy(x => x.Company_Id );
            return View(data);
        }

        // Total Sales Summary
        public ActionResult sales_summary()
        {
            con = new Models.SalesConn();
            Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
            ViewBag.From_Date = frm.From_Date.ToString("dd-MMM-yyyy");
            ViewBag.To_Date = frm.To_Date.ToString("dd-MMM-yyyy");
            if (frm.Dr_Account_Id != null)
                ViewBag.To_Party = "To Party : " + con.Companies.FirstOrDefault(x => x.Id == frm.Dr_Account_Id).Name;
            else
                ViewBag.To_Party = "ALL";
            ViewBag.From_Party = frm.Cr_Account_Id == null ? "ALL" : con.Companies.FirstOrDefault(x => x.Id == frm.Cr_Account_Id).Name;
            ViewBag.RateApplied = frm.RateBy.ToString();
            ViewBag.Branch = frm.Branch_Id == null ? "ALL" : con.Branches.FirstOrDefault(x => x.Id == frm.Branch_Id).Name;

            IEnumerable<Models.Invoice> data = con.Invoices.Where(x => x.Invoice_Date >= frm.From_Date && x.Invoice_Date <= frm.To_Date
                && (frm.Cr_Account_Id == null ? true : x.Supplier_Id == frm.Cr_Account_Id)
                && (frm.Dr_Account_Id == null ? true : x.Company_Id == frm.Dr_Account_Id)
                && (frm.Product_Id == null ? true : x.Product_Id == frm.Product_Id)
                && (frm.Sec_Tranport_Id == null ? true : x.Second_Transport_Id == frm.Sec_Tranport_Id)
                && (frm.Branch_Id == null ? true : x.Branch_Id == frm.Branch_Id)).ToArray();

            return View(data);
        }

        #endregion

        #region Common Functions

        public static bool Calc(ref Models.Invoice inv, int RateBy)
        {
            inv.B_Rate = RateBy == 0 ? inv.C_Rate : inv.B_Rate;
            inv.Invoice_Amount = Math.Round(Convert.ToDecimal(inv.Weight * inv.B_Rate), 0);
            inv.VAT_Amount = Math.Round(Convert.ToDecimal(inv.Invoice_Amount * (inv.VAT_Rate / 100)),0);
            return true;
        }

        //public static bool Rate(ref Models.Transaction inv, int RateBy)
        //{
            
        //    inv.Amount1 = RateBy == 1 ? inv.Amount2 : inv.Amount1;
        //    if (inv.Particular == "Reciept" || inv.Particular == "Discount" || inv.Particular == "Rebate")
        //        return (RateBy == 1 ? (inv.Amount2 > 0) : (inv.Amount1 > 0));
        //    return true;
        //}

        //public bool Rate(ref Models.Transaction inv, int RateBy)
        //{
        //    int Id = 0;
        //    inv.Amount1 = RateBy == 1 ? inv.Amount2 : inv.Amount1;
        //    if (inv.Voucher_No.StartsWith("I-"))
        //    {
        //        Id = Convert.ToInt32(inv.Voucher_No.Split('-')[1]);
        //        if (inv.Particular == "Sales")
        //        {
        //            //inv.Voucher_No = Convert.ToString(Id);   RateBy == 0 && 
        //            inv.Voucher_No = Convert.ToString(con.Invoices.FirstOrDefault(x => x.Id == Id).Invoice_No.ToString());
        //            //var vAmt = con.Invoices.FirstOrDefault(x => x.Id == Id).VAT_Amount;
        //            //inv.Amount1 = inv.Amount1;
        //        }
        //    }

        //    if (inv.Particular == "Sales" || inv.Particular == "frieght")
        //    {

        //        if (inv.Particular == "frieght")
        //            inv.Particular = "To " + "freight";
        //        else
        //        {
        //            if (inv.Voucher_No.StartsWith("I-"))
        //            {
        //                Id = Convert.ToInt32(inv.Voucher_No.Split('-')[1]);
        //            }
        //            inv.Particular = "To " + con.Invoices.FirstOrDefault(x => x.Id == Id).Product.Name;
        //        }
        //    }

        //    if (inv.Particular == "Reciept" || inv.Particular == "Discount" || inv.Particular == "Rebate")
        //    {
        //        DateTime? dfrom = null, dto = null;
        //        if (Request.Cookies["FY"] != null)
        //        {
        //            dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
        //            dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
        //        }
        //        var l = con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault();

        //        if(inv.Particular == "Discount") inv.Particular="Credit Note"; 

        //        string vNo = "0";
        //        bool recExist = false;

        //        inv.Particular = "By " + inv.Particular;
        //        vNo = inv.Voucher_No;
        //        Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
        //        ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");

        //        //inv.Voucher_No = con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo).Cheque.ToString();
        //        //inv.Voucher_No = inv.Voucher_No + " [" + Convert.ToString(con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo).Bank.ToString()) + "]";
        //        //inv.Voucher_No = con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault(x => x.Receipt_No == vNo).Cheque.ToString();
        //        recExist = !string.IsNullOrEmpty(con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo).ToString());
        //        if (recExist == true)
        //        {
        //            var cheqNo = Convert.ToString(con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).Where(x => x.Cheque != null).FirstOrDefault(x => x.Receipt_No == vNo).Cheque.ToString());
        //            var bankName = Convert.ToString(con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto && x.Receipt_No == vNo).Where(x => x.Bank != null).FirstOrDefault(x => x.Receipt_No == vNo).Bank.ToString());
        //            inv.Voucher_No = cheqNo + " [" + bankName + "]";
        //        } 
                
        //            //inv.Voucher_No = inv.Voucher_No + " [" + Convert.ToString(con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault(x => x.Receipt_No == vNo).Bank.ToString()) + "]";


        //        return (RateBy == 1 ? (inv.Amount2 > 0) : (inv.Amount1 > 0));
        //    }
           
        //    return true;
        //}

        public bool Rate(ref Models.Transaction inv, int RateBy)
        {
            int Id = 0;
            inv.Amount1 = RateBy == 1 ? inv.Amount2 : inv.Amount1;
            if (inv.Voucher_No.StartsWith("I-"))
            {
                Id = Convert.ToInt32(inv.Voucher_No.Split('-')[1]);
                if (inv.Particular == "Sales")
                {
                    //inv.Voucher_No = Convert.ToString(Id);   RateBy == 0 && 
                    inv.Voucher_No = Convert.ToString(con.Invoices.FirstOrDefault(x => x.Id == Id).Invoice_No.ToString());
                    //var vAmt = con.Invoices.FirstOrDefault(x => x.Id == Id).VAT_Amount;
                    //inv.Amount1 = inv.Amount1;
                }
            }

            if (inv.Particular == "Sales" || inv.Particular == "frieght")
            {

                if (inv.Particular == "frieght")
                    inv.Particular = "To " + "freight";
                else
                {
                    if (inv.Voucher_No.StartsWith("I-"))
                    {
                        Id = Convert.ToInt32(inv.Voucher_No.Split('-')[1]);
                    }
                    inv.Particular = "To " + con.Invoices.FirstOrDefault(x => x.Id == Id).Product.Name;
                }
            }

            if (inv.Particular == "Reciept" || inv.Particular == "Discount" || inv.Particular == "Rebate")
            {
                DateTime? dfrom = null, dto = null;
                if (Request.Cookies["FY"] != null)
                {
                    dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                    dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
                }
                var l = con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault();


                string vNo = "0";
                bool recExist = false;
                inv.Particular = "By " + inv.Particular;
                vNo = inv.Voucher_No;
                Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
                ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");

                //inv.Voucher_No = con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo).Cheque.ToString();
                //inv.Voucher_No = inv.Voucher_No + " [" + Convert.ToString(con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo).Bank.ToString()) + "]";
                //inv.Voucher_No = con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault(x => x.Receipt_No == vNo).Cheque.ToString();
                recExist = string.IsNullOrEmpty(con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo).ToString());
                if (recExist == true)
                    inv.Voucher_No = inv.Voucher_No + " [" + Convert.ToString(con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault(x => x.Receipt_No == vNo).Bank.ToString()) + "]";


                return (RateBy == 1 ? (inv.Amount2 > 0) : (inv.Amount1 > 0));
            }
            return true;
        }

        public bool StateRate(ref Models.Transaction inv, int RateBy)
        {
            inv.Amount1 = RateBy == 1 ? inv.Amount2 : inv.Amount1;

            if (inv.Particular == "Reciept" || inv.Particular == "Discount" || inv.Particular == "Rebate")
            {
                //string cheqNo = string.Empty;
                //string bankName = string.Empty;
                DateTime? dfrom = null, dto = null;
                if (Request.Cookies["FY"] != null)
                {
                    dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                    dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
                }
                //var l = con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault();
                var vno = inv.Voucher_No.ToString();
                if (inv.Particular == "Discount") inv.Particular = "Credit Note";
                inv.Particular = "By " + inv.Particular;

                //inv.Voucher_No = con.Receipts.FirstOrDefault(x => x.Receipt_No == vno).Cheque.ToString();
                //inv.Voucher_No = inv.Voucher_No + " [" + Convert.ToString(con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo).Bank.ToString()) + "]";
                //TrasnsDetail = con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault(x => x.Receipt_No == vno).Cheque.ToString();
                var cheqNo = Convert.ToString(con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).Where(x => x.Cheque != null).FirstOrDefault(x => x.Receipt_No == vno).Cheque.ToString());
                var bankName = Convert.ToString(con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto && x.Receipt_No == vno).Where(x => x.Bank != null).FirstOrDefault(x => x.Receipt_No == vno).Bank.ToString());

                if (cheqNo != "0" && cheqNo != "")
                    inv.Voucher_No = cheqNo + " [" + bankName + " ]";// TransDetail + " [" + con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault(x => x.Receipt_No == vno).Bank.ToString() + "] ";
                else
                    inv.Voucher_No = "";

                //Transport.Models.Account_Report frm = (Transport.Models.Account_Report)TempData["frm"];
                //ViewBag.From_Date = frm.From_Date.ToString("dd/MMM/yyyy");
                return (RateBy == 1 ? (inv.Amount2 > 0) : (inv.Amount1 > 0));
            }
            return true;
        }

        public bool Rate1(ref Models.Transaction inv, int RateBy)
        {
            //if (RateBy == 0 && inv.Particular == "Sales")
            //{
            //    int Id = Convert.ToInt32(inv.Voucher_No.Split('-')[1]);
            //    var vAmt = con.Invoices.FirstOrDefault(x => x.Id == Id).VAT_Amount;
            //    inv.Amount1 = vAmt + inv.Amount1;
            //}

            //if (RateBy == 1)
            //    return (inv.Amount2 > 0);
            //else  
            //    return (inv.Amount1 > 0);
            return (RateBy == 1 ? (inv.Amount2 > 0) : (inv.Amount1 > 0));
        }
        
        public bool RateAcc(ref Models.Transaction inv, int RateBy)
        {
            if (RateBy == 0 && inv.Particular == "Sales")
            {
                int Id = Convert.ToInt32(inv.Voucher_No.Split('-')[1]);
                //var vAmt = con.Invoices.FirstOrDefault(x => x.Id == Id).VAT_Amount;
                //inv.Amount1 = vAmt + inv.Amount1;
            }
            return (RateBy == 1 ? (inv.Amount2 > 0) : (inv.Amount1 > 0));
        }

        public bool TRate(ref Models.Transaction inv)
        {
            int Id = 0;
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }
            if (inv.Voucher_No.StartsWith("B-"))
            {
                Id = Convert.ToInt32(inv.Voucher_No.Split('-')[1]);
                if (inv.Particular == "frieght")
                {
                    //inv.Voucher_No = Convert.ToString(Id);
                    inv.Voucher_No = Convert.ToString(con.Invoices.FirstOrDefault(x => x.Id == Id).Billty_No.ToString());
                }
            }
            else if (inv.Voucher_No.StartsWith("RCP") || inv.Voucher_No.StartsWith("RBT") || inv.Voucher_No.StartsWith("DIC"))
            {
                string vNo;
                vNo = inv.Voucher_No;
                inv.Voucher_No = Convert.ToString(con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo && x.Receipt_Date >= dfrom && x.Receipt_Date <= dto ).Cheque.ToString());
                inv.Voucher_No = inv.Voucher_No + " [" + Convert.ToString(con.Receipts.FirstOrDefault(x => x.Receipt_No == vNo && x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).Bank.ToString()) + "]";
            }

            if (inv.Particular == "frieght")
            {
                inv.Particular = "To " + con.Invoices.FirstOrDefault(x => x.Id == Id).Product.Name;
            }

            if (inv.Particular == "Reciept" || inv.Particular == "Discount" || inv.Particular == "Rebate")
            {
                if (inv.Particular == "Reciept")
                {
                    inv.Particular = "By Receipt";
                }
                else
                {
                    inv.Particular = "By " + inv.Particular;
                }
            }
            return true;
        }

        #endregion      

    }
}
