﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace Transport.Controllers
{
    [Authorize]
    public class TransportersController : Controller
    {
        //
        // GET: /Master/
        Models.SalesConn con;
        SelectListItem[] arr = new SelectListItem[] { new SelectListItem() { Text = "ALL", Value = "0" }, new SelectListItem() { Text = "Main Transport", Value = "3" }, new SelectListItem() { Text = "Secondary Transport", Value = "4" } };
        int pageSize = 10;
        int Branch_id = 0;
        public ActionResult Index(int? page)
        {
            int pageNumber = (page ?? 1);
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            ViewBag.ComType = new SelectList(arr, "Value", "Text");
            return View(con.Companies.Where(x => x.Id > 0 && (x.Type == 3 || x.Type == 4) && x.Company_Branches.Where(y=> y.Branch_Id== Branch_id).Count()==1 ).OrderBy(x=> x.Name).ToPagedList(pageNumber, pageSize));
        }

        [HttpPost]
        public ActionResult Index(int? page ,FormCollection frm)
        {
            Branch_id = common.GetBranch_Id(Request);
            int pageNumber = (page ?? 1);
            int Type = Convert.ToInt32(frm["ddlType"]);
            ViewBag.ComType = new SelectList(arr, "Value", "Text", Type);
            con = new Models.SalesConn();
            return View(con.Companies.Where(x => x.Id > 0 && (Type == 0 ? (x.Type == 3 || x.Type == 4) : x.Type == Type) && x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0).OrderBy(x => x.Name).ToPagedList(pageNumber, pageSize));
        }
        //
        // GET: /Master/Edit/5

        public ActionResult Transporter(int id)
        {
            con = new Models.SalesConn();
            ViewBag.Branches = con.Branches.ToList();
            ViewBag.ComType = new SelectList(arr.Where(x => x.Value != "0"), "Value", "Text");
            Models.Company _con = con.Companies.FirstOrDefault(x => x.Id == id);

            return View(_con ?? new Models.Company());
        }

        //
        // POST: /Master/Edit/5

        [HttpPost]
        public ActionResult Transporter(Models.Company _com, FormCollection frm)
        {
            try
            {
                con = new Models.SalesConn();
                ViewBag.Branches = con.Branches.ToList();
                
                ViewBag.ComType = new SelectList(arr.Where(x => x.Value != "0"), "Value", "Text");
                Models.Company com = con.Companies.FirstOrDefault(x => x.Id == _com.Id);
                if (com == null)
                    com = new Models.Company();
                
                com.Name = _com.Name;
                com.Account_No = _com.Account_No;
                com.Address = _com.Address;
                com.Bank = _com.Bank;
                com.City = _com.City;
                com.CST_NO = _com.CST_NO;
                com.Email = _com.Email;
                com.Fax = _com.Fax;
                com.Mobile = _com.Mobile;
                com.Phone_1 = _com.Phone_1;
                com.Phone_2 = _com.Phone_2;
                com.RTGS = _com.RTGS;
                com.GST_NO = _com.GST_NO;
                com.State = _com.State;
                com.Status = _com.Status;
                com.Type = _com.Type;
                com.BillType = "";
                com.Unit_Name = _com.Unit_Name;
                com.Zip = _com.Zip;
                com.Reg_No = _com.Reg_No;
                com.Pan_No = _com.Pan_No;
                com.TIN  = _com.TIN;
                com.Dist = _com.Dist;
                Models.Company_Branches[] brs = com.Company_Branches.ToArray();
                foreach (var item in brs)
                {
                    con.Company_Branches.Remove(item);
                }

                foreach (var item in frm.AllKeys.Where(x => x.Contains("chk_")))
                {
                    if (frm[item] == "on")
                    {
                        com.Company_Branches.Add(new Models.Company_Branches() { Branch_Id = Convert.ToInt32(item.Split('_')[1]), Company_Id = com.Id });
                    }
                }

                if (_com.Id == 0)
                    con.Companies.Add(com);
                con.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                con = new Models.SalesConn();
                Models.Company _con = con.Companies.FirstOrDefault(x => x.Id == id);
                
                Models.Company_Branches[] brs = _con.Company_Branches.ToArray();
                foreach (var item in brs)
                {
                    con.Company_Branches.Remove(item);
                }

                if (_con != null)
                    con.Companies.Remove(_con);

                con.SaveChanges();
                TempData["message"] = "Deleted Successfully";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                TempData["message"] = "Connot deleted this record!";
                return RedirectToAction("Index");
            }

        }

    }
}
