﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using Transport.Models;
using System.Data.Entity.Validation;
namespace Transport.Controllers
{
    [Authorize]
    public class OnlyInvoicesController : Controller
    {
        //
        // GET: /Invoices/
        int pageSize = 10;
        int Branch_id = 0;
        Models.SalesConn con;
        public ActionResult Index(int? page, int? comp, string filter, string value)
        {
            int pageNumber = (page ?? 1);
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }

            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            var rep = con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray();
            ViewBag.Companies = new SelectList(rep, "Id", "Name", comp);
            ViewBag.company_id = comp;
            if (Session.Count > 0)
            {
                string sdata = Session["Type"].ToString();
                ViewBag.RId = sdata;
            }
            else
            {
                Session.Abandon();
                Session.Clear();
                TempData["message1"] = "Your session is timeout please login again for continue !";
                return RedirectToAction("Logout", "Home");
            }

            if (value == "" || value == null)
            {
                var LQr = con.Invoices.Where(x => (x.Invoice_Date >= dfrom.Value && x.Invoice_Date <= dto.Value) && x.Branch_Id == Branch_id && x.Transport_Id == -1 && (comp == null ? true : x.Company_Id == comp.Value)).OrderByDescending(x => x.Id).ToPagedList(pageNumber, pageSize);
                return View(LQr);
            }
            else
            {
                var LQs = con.Invoices.Where(x => (x.Invoice_Date >= dfrom.Value && x.Invoice_Date <= dto.Value) && x.Branch_Id == Branch_id && x.Transport_Id == -1 && (comp == null ? true : x.Company_Id == comp.Value)).ToList();
                return View(LQs.Where(x => GetPropertyValue(x, filter, value)).ToPagedList(pageNumber, pageSize));
            }
        }

        public bool GetPropertyValue(Invoice obj, string property, string value)
        {
            switch (property)
            {
                case "Invoice_No":
                    return obj.Invoice_No.ToString().Contains(value);
                case "Invoice_Date":
                    return obj.Invoice_Date.ToString().Contains(value);
                case "Truck_No":
                    return obj.Truck_No.ToString().Contains(value);
                default:
                    return false;
            }
        }

        public ActionResult Invoice(int? id, int? comp)
        {

            con = new Models.SalesConn();
            Branch_id = common.GetBranch_Id(Request);

            Models.Company com = con.Companies.FirstOrDefault(x => x.Id == comp);
            Models.Invoice _f = id == null ? new Invoice() { Loading_Id = 5, Royalty_No = "Paid", Truck_No = "", Id = 0, Invoice_Date = DateTime.Now.Date, Company = com, BillType = com.BillType, Company_Id = comp.Value } : con.Invoices.FirstOrDefault(x => x.Id == id);
            if (comp == null)
                ViewBag.Companies = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id == -1 && x.Branch_Id == Branch_id && x.Active == true && x.Product_Id == _f.Product_Id).Select(x => new { Name = x.Company1.Name, Id = x.Company1.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
            else
                ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Id == comp.Value).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");

            ViewBag.Supplier = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id == -1 && x.Branch_Id == Branch_id && x.Active == true && x.Company_Id == _f.Company_Id).Select(x => new { Name = x.Company.Name, Id = x.Company.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
            ViewBag.Products = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id == -1 && x.Branch_Id == Branch_id && x.Company_Id == _f.Company_Id && x.Active == true).Select(x => new { x.Product.Name, x.Product_Id }).OrderBy(x => x.Name).ToArray(), "Product_Id", "Name");
            ViewBag.Loadings = new SelectList(con.Loadings.Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
            //ViewBag.TruckNo = new SelectList(con.Vehicles.Select(x => new { x.Name, x.Id }).ToArray(), "Name", "Name");
            return View(_f);
        }

        [HttpPost]
        public ActionResult Invoice(Models.Invoice I, FormCollection frm)
        {

            using (var ts = new System.Transactions.TransactionScope())
            {
                con = new Models.SalesConn(); try
                {

                    Branch_id = common.GetBranch_Id(Request);
                    int transType = 0;
                    Models.Invoice _I = con.Invoices.FirstOrDefault(x => x.Id == I.Id);
                    if (ModelState.IsValid)
                    {
                        if (_I == null)
                        {
                            _I = new Models.Invoice();
                            _I.Billty_No = 0;
                            _I.Invoice_No = GetNewInvoiceNo(I.Supplier_Id);
                            _I.Form_No = 0;
                            _I.Branch_Id = Branch_id;
                            transType = 1;
                        }
                        _I.Invoice_Date = I.Invoice_Date;
                        _I.Advance = I.Advance;
                        _I.Product_Id = I.Product_Id;
                        _I.Supplier_Id = I.Supplier_Id;
                        _I.Transport_Id = I.Transport_Id;
                        _I.Company_Id = I.Company_Id;
                        _I.Loading_Id = I.Loading_Id;
                        //_I.Loading_Id = I.Loading_Id;

                        _I.From_City = I.From_City;
                        _I.To_City = I.To_City;
                        _I.Code_1 = I.Code_1 ?? 0;
                        _I.Code_2 = I.Code_2 ?? 0;
                        _I.Truck_No = I.Truck_No;
                        string vehNo = I.Truck_No;
                        _I.Pan_Card = I.Pan_Card;
                        _I.Owner_Name = I.Owner_Name;
                        _I.TDS_Tax = I.TDS_Tax ?? 0;
                        _I.Royalty_No = I.Royalty_No;
                        _I.BillType = I.BillType;
                        _I.Second_Transport_Id = 0;


                        _I.Driver_Name = string.Empty;
                        _I.Driver_Address = string.Empty;
                        _I.Driver_Licence = string.Empty;
                        _I.Remarks = string.Empty;
                        _I.Freight_Rate = 0;
                        _I.Freight = 0;

                        _I.B_Rate = I.B_Rate;
                        _I.C_Rate = I.C_Rate;
                        _I.Weight = I.Weight;

                        _I.Invoice_Amount = Math.Round((I.B_Rate.Value * I.Weight), 0);

                        _I.VAT_Rate = I.VAT_Rate;
                        _I.VAT_Amount = Math.Round((_I.Invoice_Amount.Value * (I.VAT_Rate.Value / 100)), 0);
                        if (_I.BillType == "To be billed")
                            _I.Deposit_Amount = (I.Weight * (I.Code_1 * 10));
                        else
                            _I.Deposit_Amount = (I.Weight * (I.Code_2.Value * 10));

                        string Voucher_No = ("I-" + _I.Id.ToString());
                        //_I.Deposit_Amount = I.Deposit_Amount;
                        Vehicle _vehdetail = con.Vehicles.FirstOrDefault(x => x.Name == vehNo);

                        if (_I.Id == 0)
                            con.Invoices.Add(_I);
                        con.SaveChanges();


                        Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);

                        if (_trans == null)
                            _trans = new Transaction();
                        //_trans.Amount1 = Math.Round((_I.B_Rate * _I.Weight),0);

                        if (_I.B_Rate != Convert.ToInt32("0"))
                        {
                            _trans.Amount1 = Math.Round(((_I.B_Rate.Value * _I.Weight) + _I.VAT_Amount.Value), 0);
                        }
                        else
                            _trans.Amount1 = 0;
                        //_trans.Amount1 = Math.Round((_I.B_Rate.Value * _I.Weight) * (_I.VAT_Rate.Value / 100), 0);
                        _trans.Amount2 = Math.Round((_I.C_Rate.Value * _I.Weight), 0);
                        _trans.Cr_Account_Id = _I.Supplier_Id;
                        _trans.Dr_Account_Id = _I.Company_Id;
                        _trans.DrCr = "Dr";
                        _trans.Particular = "Sales";
                        _trans.Voucher_Date = _I.Invoice_Date;
                        _trans.Voucher_No = "I-" + _I.Id.ToString();

                        if (_trans.Id == 0)
                            con.Transactions.Add(_trans);
                        con.SaveChanges();


                        bool vehStatus = true;
                        if (_vehdetail == null)
                            _vehdetail = new Vehicle();
                        _vehdetail.Name = _I.Truck_No;
                        _vehdetail.Owner_Name = _I.Owner_Name;
                        _vehdetail.TDS_Tax = _I.TDS_Tax.Value;
                        _vehdetail.Pan_Card = _I.Pan_Card;
                        _vehdetail.Register_Date = DateTime.Now;
                        _vehdetail.Status = vehStatus;
                        if (_vehdetail.Id == 0)
                            con.Vehicles.Add(_vehdetail);
                        con.SaveChanges();
                        ts.Complete();
                        //TempData["message"] = "Invoice Saved Succcessfully";

                        if (transType == 1)
                            TempData["message"] = "New Invoice No  added Succcessfully";
                        else
                            TempData["message"] = "Old Invoice No  updated Succcessfully";

                    }
                    return RedirectToAction("Index", "onlyinvoices", new { comp = _I.Company_Id });
                }
                catch (Exception e)
                {
                   
                    ts.Dispose();
                    ViewBag.Sub_Tranporters = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && (x.Type == 4)).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                    ViewBag.Products = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id == -1 && x.Branch_Id == Branch_id && x.Company_Id == I.Company_Id && x.Active == true).Select(x => new { x.Product.Name, x.Product_Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Product_Id", "Name");
                    ViewBag.Supplier = new SelectList(con.Invoice_Rates.Where(x => x.Transport_Id == -1 && x.Branch_Id == Branch_id && x.Active == true && x.Company_Id == I.Company_Id).Select(x => new { Name = x.Company.Name, Id = x.Company.Id }).OrderBy(x => x.Name).Distinct().ToArray(), "Id", "Name");
                    ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && (x.Type == 2)).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                    ViewBag.Loadings = new SelectList(con.Loadings.Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
                   
                    return View(I);
                    throw (e);
                }

            }
        }

        public ActionResult Delete(int Id)
        {
            con = new Models.SalesConn();
            using (var ts = new System.Transactions.TransactionScope())
            {
                try
                {
                    Models.Invoice _I = con.Invoices.FirstOrDefault(x => x.Id == Id);

                    if (_I != null)
                        con.Invoices.Remove(_I);

                    string Voucher_No = ("I-" + _I.Id.ToString());
                    Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                    if (_trans != null)
                        con.Transactions.Remove(_trans);

                    Voucher_No = ("B-" + _I.Id.ToString());
                    Transaction _frieght = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                    if (_frieght != null)
                        con.Transactions.Remove(_frieght);

                    con.SaveChanges();
                    ts.Complete();
                    TempData["message"] = "Invoice Deleted Succcessfully";
                    return RedirectToAction("Index", "onlyinvoices", new { comp = _I.Company_Id });
                }
                catch (Exception e)
                {
                    ts.Dispose();
                    return View();
                }
            }
        }

        public JsonResult SelectCompany(int? product_id, int? company_id, int? supplier_Id)
        {
            con = new Models.SalesConn();
            Branch_id = common.GetBranch_Id(Request);
            decimal vatrate = Convert.ToDecimal(con.Configs.FirstOrDefault(x => x.Variable == "VAT_Rate").Value);
            decimal other_vatrate = Convert.ToDecimal(con.Configs.FirstOrDefault(x => x.Variable == "Other_VAT_Rate").Value);
            Models.Invoice_Rates rate = con.Invoice_Rates.FirstOrDefault(x => x.Branch_Id == Branch_id && x.Product_Id == product_id && x.Company_Id == company_id && x.Transport_Id == -1 && (supplier_Id == null ? true : x.Supplier_Id == supplier_Id));
            if (rate == null)
            { return Json(new { status = "Error", msg = "Invoice Rate is missing for this product!" }, JsonRequestBehavior.AllowGet); }

            var temp = new { status = "Success", msg = "", rate.B_Rate, rate.C_Rate, Supplier_Id = rate.Supplier_Id, Transport_Id = rate.Transport_Id, From = rate.Company.City, To = rate.Company1.City, FrieghtRate = 0, VAT = (rate.Company.State.ToUpper().Trim() == rate.Company1.State.ToUpper().Trim() ? vatrate : other_vatrate), Company_Id = rate.Company1.Id, Freigt = 0 };
            return Json(temp, JsonRequestBehavior.AllowGet);
        }

        public int GetNewInvoiceNo(int Supplier_Id)
        {
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }
            var l = con.Invoices.Where(x => (x.Invoice_Date >= dfrom.Value && x.Invoice_Date <= dto.Value) && x.Supplier_Id == Supplier_Id).OrderByDescending(x => x.Invoice_No).FirstOrDefault();
            return l == null ? 1 : (l.Invoice_No + 1);
        }

        public JsonResult SelectPreStatus(string truck_no)
        {
            con = new Models.SalesConn();
            if (truck_no != null)
            {
                Models.Vehicle delsta = con.Vehicles.FirstOrDefault(x => x.Name == truck_no);
                if (delsta == null)
                {
                    return Json(new { status = "Error", msg = "Please mention the Pan Card No,Owner name,TDS Tax Rate !" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var vehrelated = new { status = "Success", msg = "", delsta.Pan_Card, delsta.Owner_Name, delsta.TDS_Tax };
                    return Json(vehrelated, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json(new { status = "Error", msg = "Blank Truck No is not allowed" }, JsonRequestBehavior.AllowGet);
            }
        }

    }
}
