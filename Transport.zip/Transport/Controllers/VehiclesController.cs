﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transport.Models;
using Transport.Converter;
using PagedList;
namespace Transport.Controllers
{
    [Authorize]
    public class VehiclesController: Controller
    {
        //
        // GET: /Materials/
        Models.SalesConn con;
        int pageSize = 10;
        public ActionResult Index(int? page, string filter, string value)
        {
            if (TempData["ViewData"] != null)
            {
                ViewData = (ViewDataDictionary)TempData["ViewData"];
            }
            int pageNumber = (page ?? 1);
            con = new Models.SalesConn();
            var LQr=con.Vehicles.OrderBy(x => x.Name).ToPagedList(pageNumber, pageSize);

            if (filter == null)
                return View(LQr);
            else
                return View(LQr.Where(x => GetPropertyValue(x, filter, value)).ToPagedList(pageNumber, pageSize));
 
            //return View(con.Vehicles.OrderBy(x => x.Name).ToPagedList(pageNumber, pageSize));
        }

        public bool GetPropertyValue(Vehicle obj, string property, string value)
        {
            switch (property)
            {
                case "Truck_No":
                    return obj.Name.ToString().Contains(value);
                case "Status":
                    return obj.Status.ToString().Contains(value);
                default:
                    return false;
            }
        }

        // GET: /Materials/Create
        public ActionResult Vehicle(int id)
        {
            con = new Models.SalesConn();
            Models.Vehicle _p = con.Vehicles.FirstOrDefault(x => x.Id == id);
            return View(_p ?? new Models.Vehicle());
        }

        // POST: /Materials/Create
        [HttpPost]
        public ActionResult Vehicle(Models.Vehicle _lod)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    con = new Models.SalesConn();
                    Models.Vehicle lod = con.Vehicles.FirstOrDefault(x => x.Id == _lod.Id);
                    if (lod == null)
                        lod = new Models.Vehicle();
                    lod.Name = _lod.Name;
                    lod.Owner_Name = _lod.Owner_Name;
                    lod.Pan_Card = _lod.Pan_Card;
                    lod.TDS_Tax = _lod.TDS_Tax;
                    lod.Register_Date = DateTime.Now;
                    lod.Status = _lod.Status;
                    if (lod.Id == 0)
                        con.Vehicles.Add(lod);
                    con.SaveChanges();
                    return RedirectToAction("Index", "Vehicles");
                }
                else
                {
                    TempData["ViewData"] = ViewData;
                    return RedirectToAction("Index");
                }
            }
            catch
            {
                return View();
            }
        }

        // POST: /Materials/Create
       
    }
}
