﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using Transport.Models;
namespace Transport.Controllers
{
    public class TransController : Controller
    {
        int pageSize = 10;
        int Branch_id = 0;
        Models.SalesConn con;

        SelectListItem[] arr = new SelectListItem[] { new SelectListItem() { Text = "Reciept", Value = "RCP" }, new SelectListItem() { Text = "Discount", Value = "DIC" }, new SelectListItem() { Text = "Rebate", Value = "RBT" } };
        SelectListItem[] arrrt = new SelectListItem[] { new SelectListItem() { Text = "Bill Reciept", Value = "0" }, new SelectListItem() { Text = "Cash Reciept", Value = "1" }};

        public bool GetPropertyValue(Receipt obj, string value)
        {          
            return obj.Company1.Name.ToString().Contains(value); 
        }

        #region Party by suppliers
        public ActionResult partybysuppliers(int? page,int? comp)
        {
            int pageNumber = (page ?? 1);
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            var suppliers = con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 1).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name);
            ViewBag.Companies = new SelectList(suppliers, "Id", "Name",comp);
            return View(con.Transactions.Where(x => x.Particular == "Opening Balance" && x.Cr_Account_Id == (comp==null ? suppliers.FirstOrDefault().Id : comp)).OrderByDescending(x => x.Company1.Name).ToPagedList(pageNumber, pageSize));
        }

        public ActionResult partybysupplier(int? id, int? comp)
        {
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            Transaction _frm = (id == null ? new Transaction() { Voucher_Date= DateTime.Now.Date } : con.Transactions.FirstOrDefault(x => x.Id == id));
            _frm.Cr_Account_Id = comp == null ? _frm.Cr_Account_Id : comp.Value;

            ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 1).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            ViewBag.Receipant = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            return View(_frm);
        }

        [HttpPost]
        public ActionResult partybysupplier(Transaction frm)
        {
            try
            {
                con = new Models.SalesConn();
                Transaction _frm = con.Transactions.FirstOrDefault(x => x.Cr_Account_Id == frm.Cr_Account_Id && x.Dr_Account_Id == frm.Dr_Account_Id);
                if (ModelState.IsValid)
                {
                    if (_frm == null)
                        _frm = new Transaction();
                    _frm.Particular = "Opening Balance";
                    _frm.Amount1 = frm.Amount1;
                    _frm.Amount2 = frm.Amount2;
                    _frm.Cr_Account_Id = frm.Cr_Account_Id;
                    _frm.Dr_Account_Id = frm.Dr_Account_Id;
                    _frm.DrCr = frm.DrCr;
                    _frm.Voucher_Date = frm.Voucher_Date;
                    _frm.Voucher_No = "PS-" + _frm.Dr_Account_Id;

                    if (_frm.Id == 0)
                        con.Transactions.Add(_frm);
                    con.SaveChanges();
                    return RedirectToAction("partybysuppliers", "trans", new { comp = _frm.Cr_Account_Id });
                }
                else
                {
                    return View(frm);
                }
            }
            catch (Exception)
            {
                return View(frm);
            }
            
        }

        public ActionResult partybysupplierdelete(int id)
        {
            try
            {
                con = new Models.SalesConn();
                Transaction _frm = con.Transactions.FirstOrDefault(x => x.Id == id);
                if (_frm != null)
                    con.Transactions.Remove(_frm);
               
                con.SaveChanges();
                TempData["message"] = "Selected Record Deleted Successfully";
                return RedirectToAction("partybysuppliers", "trans", new { comp = _frm.Cr_Account_Id });
            }
            catch (Exception)
            {
                TempData["message"] = "Connot deleted this record!";
                return RedirectToAction("partybysuppliers", "trans");
            }

        }

        #endregion

        #region Party by trasporters

        public ActionResult partybytrasporters(int? page, int? comp)
        {
            int pageNumber = (page ?? 1);
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            var suppliers = con.Companies.Where(x => x.Id > 0 &&  x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 3).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name);
            ViewBag.Companies = new SelectList(suppliers, "Id", "Name", comp);
            return View(con.Transactions.Where(x => x.Particular == "Opening Balance" && x.Cr_Account_Id == (comp == null ? suppliers.FirstOrDefault().Id : comp)).OrderByDescending(x => x.Company1.Name).ToPagedList(pageNumber, pageSize));
        }

        public ActionResult partybytrasporter(int? id, int? comp)
        {
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            Transaction _frm = (id == null ? new Transaction() { Voucher_Date = DateTime.Now.Date } : con.Transactions.FirstOrDefault(x => x.Id == id));
            _frm.Cr_Account_Id = comp==null ? _frm.Cr_Account_Id : comp.Value;
            ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Id > 0 && x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 3).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            ViewBag.Receipant = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            return View(_frm);
        }

        [HttpPost]
        public ActionResult partybytrasporter(Transaction frm)
        {
            try
            {
                con = new Models.SalesConn();
                Transaction _frm = con.Transactions.FirstOrDefault(x => x.Cr_Account_Id == frm.Cr_Account_Id && x.Dr_Account_Id == frm.Dr_Account_Id);
                if (_frm == null)
                    _frm = new Transaction();
                _frm.Particular = "Opening Balance";
                _frm.Amount1 = frm.Amount1;
                _frm.Amount2 = frm.Amount2;
                _frm.Cr_Account_Id = frm.Cr_Account_Id;
                _frm.Dr_Account_Id = frm.Dr_Account_Id;
                _frm.DrCr = frm.DrCr;
                _frm.Voucher_Date = frm.Voucher_Date;
                _frm.Voucher_No = "PT-" + _frm.Dr_Account_Id;

                if (_frm.Id == 0)
                    con.Transactions.Add(_frm);

                con.SaveChanges();
                return RedirectToAction("partybytrasporters", "trans", new {comp = _frm.Cr_Account_Id });
            }
            catch (Exception)
            {
                return View(frm);
            }

        }

        public ActionResult partybytrasporterdelete(int id)
        {
            try
            {
                con = new Models.SalesConn();
                Transaction _frm = con.Transactions.FirstOrDefault(x => x.Id == id);
                if (_frm != null)
                    con.Transactions.Remove(_frm);

                con.SaveChanges();
                TempData["message"] = "Deleted Successfully";
                return RedirectToAction("partybytrasporters", "trans", new { comp = _frm.Cr_Account_Id });
            }
            catch (Exception)
            {
                TempData["message"] = "Connot deleted this record!";
                return RedirectToAction("partybytrasporters", "trans");
            }

        }

        #endregion

        #region Party bill receipts

      
        public ActionResult partybillreceipts(int? page, int? comp, string recp)
        {
            int pageNumber = (page ?? 1);
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            
            var suppliers = con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 1).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name);
            ViewBag.Companies = new SelectList(suppliers, "Id", "Name", comp);
            ViewBag.company_id = comp;
            ViewBag.FindBillBy = recp;
            //return View(con.Receipts.Where(x => (x.Receipt_Date >= dfrom.Value && x.Receipt_Date <= dto.Value) && x.Cr_Account_Id == (comp == null ? suppliers.FirstOrDefault().Id : comp)).OrderByDescending(x => x.Company1.Name).ToPagedList(pageNumber, pageSize));

            if (recp == "" || recp == null)
            {
                var LQr = con.Receipts.Where(x => (x.Receipt_Date >= dfrom.Value && x.Receipt_Date <= dto.Value) && x.Cr_Account_Id == (comp == null ? suppliers.FirstOrDefault().Id : comp)).OrderByDescending(x => x.Receipt_Date).ToPagedList(pageNumber, pageSize);
                return View(LQr);
            }
            else
            {
                //var LQs = con.Receipts.Where(x => (x.Receipt_Date >= dfrom.Value && x.Receipt_Date <= dto.Value) && x.Cr_Account_Id == (comp == null ? suppliers.FirstOrDefault().Id : comp)).OrderByDescending(x => x.Company1.Name).ToPagedList(pageNumber, pageSize);
                var LQs = con.Receipts.Where(x => (x.Receipt_Date  >= dfrom.Value && x.Receipt_Date <= dto.Value) && (comp == null ? true : x.Cr_Account_Id== comp.Value)).ToList();
                return View(LQs.Where(x => GetPropertyValue(x, recp)).ToPagedList(pageNumber, pageSize));
            }

            //if(recp==null)
            //return View(con.Receipts.Where(x => (x.Receipt_Date >= dfrom.Value && x.Receipt_Date <= dto.Value) && x.Cr_Account_Id == (comp == null ? suppliers.FirstOrDefault().Id : comp) ).OrderByDescending(x => x.Company1.Name).ToPagedList(pageNumber, pageSize));
            //else
            //    return View(con.Receipts.Where(x => (x.Receipt_Date >= dfrom.Value && x.Receipt_Date <= dto.Value) && x.Cr_Account_Id == (comp == null ? suppliers.FirstOrDefault().Id : comp) && x.Dr_Account_Id == recp).OrderByDescending(x => x.Company1.Name).ToPagedList(pageNumber, pageSize));

        }

        public ActionResult partybillreceipt(int? id, int? comp)
        {
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            Receipt _frm = (id == null ? new Receipt() { Receipt_No = "", Receipt_Date = DateTime.Now.Date } : con.Receipts.FirstOrDefault(x => x.Id == id));
            _frm.Cr_Account_Id = comp == null ? _frm.Cr_Account_Id : comp.Value;

            Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == _frm.Receipt_No);
            if (_trans == null)
                _trans = new Transaction();

            ////List<SelectList> items = new List<SelectList>();
            ////items.Add(new SelectList { Text = "Bill Reciept", Value = "0", Selected = true });
            ////items.Add(new SelectList { Text = "Cash Reciept", Value = "1"});

            ViewBag.Types = new SelectList(arr,"Value","Text", _frm.Receipt_No.Split('-')[0]);

            ////ViewBag.Reciept_Types = items;
            ViewBag.Reciept_Types = new SelectList(arrrt, "Value", "Text", (_trans.Amount1 > 0 ? 0 : 1));
            ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 1).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            ViewBag.Receipant = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            return View(_frm);
        }

        [HttpPost]
        public ActionResult partybillreceipt(Receipt frm, FormCollection f)
        {
           using (var ts = new System.Transactions.TransactionScope())
            {
            try
            {
                con = new Models.SalesConn();
                // Saving detail in Receipt Table
                Receipt _frm = con.Receipts.FirstOrDefault(x => x.Id == frm.Id);
                //if (ModelState.IsValid)
                //{
                    if (_frm == null)
                    {
                        _frm = new Receipt();
                        _frm.Receipt_No = f["ddlType"] + "-" + GetReceiptNo().ToString();
                    }
                    string Voucher_No = _frm.Receipt_No;
                    _frm.Receipt_Date = frm.Receipt_Date;
                    _frm.Receipt_No = f["ddlType"] + "-" + _frm.Receipt_No.Split('-')[1];
                    _frm.Amount = frm.Amount;
                    _frm.Cr_Account_Id = frm.Cr_Account_Id;
                    _frm.Dr_Account_Id = frm.Dr_Account_Id;
                    _frm.Bank = frm.Bank == null ? "N/A" : frm.Bank;
                    _frm.Cheque = frm.Cheque == null ? "N/A" : frm.Cheque;

                    if (_frm.Id == 0)
                        con.Receipts.Add(_frm);
                    con.SaveChanges();

                    // Saving detail in Transaction Table
                    Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                    if (_trans == null)
                        _trans = new Transaction();

                    ////_trans.Amount1 = (f["Reciept_Types"] == "0" ? _frm.Amount : 0);
                    ////_trans.Amount2 = (f["Reciept_Types"] == "1" ? _frm.Amount : 0);
                    _trans.Amount1 = (f["RecTypes"] == "0" ? _frm.Amount : 0);
                    _trans.Amount2 = (f["RecTypes"] == "1" ? _frm.Amount : 0);

                    _trans.Cr_Account_Id = _frm.Cr_Account_Id;
                    _trans.Dr_Account_Id = _frm.Dr_Account_Id;
                    _trans.DrCr = "Cr";
                    _trans.Particular = arr.FirstOrDefault(x => x.Value == f["ddlType"]).Text;
                    _trans.Voucher_Date = _frm.Receipt_Date;
                    _trans.Voucher_No = _frm.Receipt_No;

                    if (_trans.Id == 0)
                        con.Transactions.Add(_trans);
                    con.SaveChanges();
                   TempData["message"] = "New Voucher detail added Successfully";
               // }
                    ts.Complete();
                    return RedirectToAction("partybillreceipts", "trans", new { comp = _frm.Cr_Account_Id });
                }
            catch (Exception)
            {
                ts.Dispose(); 
                return View(frm);
            }
            }

        }

        
        public ActionResult partybillreceiptdelete(int id)
        {
            using (var ts = new System.Transactions.TransactionScope())
            {            
                try
                {
                    con = new Models.SalesConn();
                    Receipt _frm = con.Receipts.FirstOrDefault(x => x.Id == id);               
                    if (_frm != null)
                        con.Receipts.Remove(_frm);               
                    con.SaveChanges();

                    string Voucher_No = _frm.Receipt_No;
                    Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                    if (_trans != null)
                        con.Transactions.Remove(_trans);
                    con.SaveChanges();
                    ts.Complete();
                    TempData["message"] = "Selected Receipt has Deleted Successfully";
                    return RedirectToAction("partybillreceipts", "trans", new { comp = _frm.Cr_Account_Id });                    
                }
                catch (Exception)
                {
                    ts.Dispose();
                    TempData["message"] = "Deletion failed , some error faced on deletion of this record!";
                    return RedirectToAction("partybillreceipts", "trans");
                }
            }
        }

        #endregion

        //redirect to thankyou page
        public ActionResult Thankyou()
        {
            TempData["alertMessage"] = "Recr saved";
            return View();
        }
        #region Party frieght receipts
        public ActionResult partyfrieghtreceipts(int? page, int? comp,string recp)
        {
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }
            int pageNumber = (page ?? 1);
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            var suppliers = con.Companies.Where(x => x.Id > 0 && x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 3).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name);
            ViewBag.Companies = new SelectList(suppliers, "Id", "Name", comp);
            ViewBag.company_id = comp;
            ViewBag.FindBy = recp;
           

            if (recp == "" || recp == null)
            {
                var LQr = con.Receipts.Where(x => (x.Receipt_Date >= dfrom.Value && x.Receipt_Date <= dto.Value) && x.Cr_Account_Id == (comp == null ? suppliers.FirstOrDefault().Id : comp)).OrderByDescending(x => x.Receipt_Date).ToPagedList(pageNumber, pageSize);
                return View(LQr);
            }
            else
            {
                var LQs = con.Receipts.Where(x => (x.Receipt_Date >= dfrom.Value && x.Receipt_Date <= dto.Value) && (comp == null ? true : x.Cr_Account_Id == comp.Value)).ToList();
                return View(LQs.Where(x => GetPropertyValue(x, recp)).ToPagedList(pageNumber, pageSize));
            }
            
            
            //return View(con.Receipts.Where(x => (x.Receipt_Date >= dfrom.Value && x.Receipt_Date <= dto.Value) && x.Cr_Account_Id == (comp == null ? suppliers.FirstOrDefault().Id : comp)).OrderByDescending(x => x.Company1.Name).ToPagedList(pageNumber, pageSize));
        }

        public ActionResult partyfrieghtreceipt(int? id, int? comp)
        {
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            Receipt _frm = (id == null ? new Receipt() { Receipt_No = "", Receipt_Date = DateTime.Now.Date } : con.Receipts.FirstOrDefault(x => x.Id == id));
            _frm.Cr_Account_Id = comp == null ? _frm.Cr_Account_Id : comp.Value;

            ViewBag.Types = new SelectList(arr, "Value", "Text", _frm.Receipt_No.Split('-')[0]);
            ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 3).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            ViewBag.Receipant = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name), "Id", "Name");
            return View(_frm);
        }

        [HttpPost]
        public ActionResult partyfrieghtreceipt(Receipt frm, FormCollection f)
        {
            using (var ts = new System.Transactions.TransactionScope())
            {
                try
                {
                    con = new Models.SalesConn();
                    Receipt _frm = con.Receipts.FirstOrDefault(x => x.Id == frm.Id);
                    if (_frm == null)
                    {
                        _frm = new Receipt();
                        _frm.Receipt_No = f["ddlType"] + "-" + GetReceiptNo().ToString();
                    }
                    string Voucher_No = _frm.Receipt_No;
                    _frm.Receipt_Date = frm.Receipt_Date;
                    _frm.Receipt_No = f["ddlType"] + "-" + _frm.Receipt_No.Split('-')[1];
                    _frm.Amount = frm.Amount;
                    _frm.Cr_Account_Id = frm.Cr_Account_Id;
                    _frm.Dr_Account_Id = frm.Dr_Account_Id;
                    _frm.Bank = frm.Bank == null ? "N/A" : frm.Bank;
                    _frm.Cheque = frm.Cheque == null ? "N/A" : frm.Cheque;
                    if (_frm.Id == 0)
                        con.Receipts.Add(_frm);
                    con.SaveChanges();

                    Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                    if (_trans == null)
                        _trans = new Transaction();
                    _trans.Amount1 = _frm.Amount;
                    _trans.Amount2 = 0;
                    _trans.Cr_Account_Id = _frm.Cr_Account_Id;
                    _trans.Dr_Account_Id = _frm.Dr_Account_Id;
                    _trans.DrCr = "Cr";
                    _trans.Particular = arr.FirstOrDefault(x => x.Value == f["ddlType"]).Text;
                    _trans.Voucher_Date = _frm.Receipt_Date;
                    _trans.Voucher_No = _frm.Receipt_No;

                    if (_trans.Id == 0)
                        con.Transactions.Add(_trans);
                    con.SaveChanges();
                    ts.Complete();
                    TempData["message"] = "Payment Detail added Successfully";

                    return RedirectToAction("partyfrieghtreceipts", "trans", new { comp = _frm.Cr_Account_Id });
                }
                catch (Exception)
                {
                    ts.Dispose();
                    return View(frm);
                }
            }
        }

        public ActionResult partyfrieghtreceiptdelete(int id)
        {
            try
            {
                con = new Models.SalesConn();
                Receipt _frm = con.Receipts.FirstOrDefault(x => x.Id ==id);
                if (_frm != null)
                    con.Receipts.Remove(_frm);

                con.SaveChanges();

                string Voucher_No = _frm.Receipt_No;
                Transaction _trans = con.Transactions.FirstOrDefault(x => x.Voucher_No == Voucher_No);
                if (_trans != null)
                    con.Transactions.Remove(_trans);

                con.SaveChanges();
                TempData["message"] = "Selected voucher detail Deleted Successfully";
                return RedirectToAction("partybillreceipts", "trans", new { comp = _frm.Cr_Account_Id });
            }
            catch (Exception)
            {
                TempData["message"] = "Connot deleted this record!";
                return RedirectToAction("partybillreceipts", "trans");
            }

        }

        #endregion

        //public int GetVoucherNo()
        //{
        //    DateTime? dfrom = null, dto = null;
        //    if (Request.Cookies["FY"] != null)
        //    {
        //        dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
        //        dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
        //    }

        //    var l = con.Transactions.Where(x=> x.Voucher_Date >= dfrom && x.Voucher_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault();
        //    return l == null ? 1 : (Convert.ToInt32(l.Voucher_No.Split('-')[1]) + 1);
        //}

        public int GetReceiptNo()
        {
            DateTime? dfrom = null, dto = null;
            if (Request.Cookies["FY"] != null)
            {
                dfrom = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[0]);
                dto = Convert.ToDateTime(Request.Cookies["FY"].Value.Split('-')[1]);
            }
            var l = con.Receipts.Where(x => x.Receipt_Date >= dfrom && x.Receipt_Date <= dto).OrderByDescending(x => x.Id).FirstOrDefault();
            //return l == null ? 1 : (Convert.ToInt32(l.Receipt_No.Split('-')[1]) + 1);
            return l == null ? 1 : (Convert.ToInt32(l.Id + 1));
        }
    }
}
