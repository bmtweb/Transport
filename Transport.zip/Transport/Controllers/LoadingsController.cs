﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace Transport.Controllers
{
    [Authorize]
    public class LoadingsController : Controller
    {
        //
        // GET: /Materials/
        Models.SalesConn con;
        int pageSize = 10;
        public ActionResult Index(int? page)
        {
            int pageNumber = (page ?? 1);
            con = new Models.SalesConn();
            return View(con.Loadings.OrderBy(x=> x.Name).ToPagedList(pageNumber, pageSize));
        }

        //
        // GET: /Materials/Create

        public ActionResult Loading(int id)
        {
            con = new Models.SalesConn();
            Models.Loading _p = con.Loadings.FirstOrDefault(x => x.Id == id);

            return View(_p ?? new Models.Loading());
        }

        //
        // POST: /Materials/Create

        [HttpPost]
        public ActionResult Loading(Models.Loading _lod)
        {
            try
            {
                con = new Models.SalesConn();
                Models.Loading lod = con.Loadings.FirstOrDefault(x => x.Id == _lod.Id);
                if (lod == null)
                    lod = new Models.Loading();

                lod.Name = _lod.Name;
                if (lod.Id == 0)
                    con.Loadings.Add(lod);
                con.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

       
    }
}
