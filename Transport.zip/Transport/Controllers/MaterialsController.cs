﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace Transport.Controllers
{
    [Authorize]
    public class MaterialsController : Controller
    {
        //
        // GET: /Materials/
        Models.SalesConn con;
        int pageSize = 10;
        int Branch_id = 0;
        public ActionResult Index(int? page)
        {
            Branch_id = common.GetBranch_Id(Request);
            int pageNumber = (page ?? 1);
            con = new Models.SalesConn();
            return View(con.Products.Where(x=> x.Product_Branches.Where(y=> y.Branch_Id== Branch_id).Count() > 0).OrderBy(x=> x.Name).ToPagedList(pageNumber, pageSize));
        }

        //
        // GET: /Materials/Create
        public ActionResult Material(int id)
        {
            con = new Models.SalesConn();
            ViewBag.Branches = con.Branches.ToList();
            Models.Product _p = con.Products.FirstOrDefault(x => x.Id == id);
            return View(_p ?? new Models.Product());
        }

        //
        // POST: /Materials/Create

        [HttpPost]
        public ActionResult Material(Models.Product _pro, FormCollection frm)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    con = new Models.SalesConn();
                    ViewBag.Branches = con.Branches.ToList();
                    Models.Product pro = con.Products.FirstOrDefault(x => x.Id == _pro.Id);
                    if (pro == null)
                        pro = new Models.Product();
                    pro.Name = _pro.Name;
                    pro.HSNCode = _pro.HSNCode;
                    pro.Active = _pro.Active;
                    
                    Models.Product_Branches[] brs = pro.Product_Branches.ToArray();
                    foreach (var item in brs)
                    {
                        con.Product_Branches.Remove(item);
                    }

                    foreach (var item in frm.AllKeys.Where(x => x.Contains("chk_")))
                    {
                        if (frm[item] == "on")
                        {
                            pro.Product_Branches.Add(new Models.Product_Branches() { Branch_Id = Convert.ToInt32(item.Split('_')[1]), Product_Id = pro.Id });
                        }
                    }
                    if (pro.Id == 0)
                        con.Products.Add(pro);
                    con.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                con = new Models.SalesConn();
                Models.Product pro = con.Products.FirstOrDefault(x => x.Id == id);
                Models.Product_Branches[] brs = pro.Product_Branches.ToArray();
                foreach (var item in brs)
                {
                    con.Product_Branches.Remove(item);
                }

                if (pro != null)
                    con.Products.Remove(pro);
                con.SaveChanges();
                TempData["message"] = "Deleted Successfully";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                TempData["message"] = "Connot deleted this record!";
                return RedirectToAction("Index");
            }
        }
    }
}
