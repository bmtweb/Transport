﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Transport.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        Models.SalesConn con;
        [Authorize]
        public ActionResult Index()
        {

            if (Request.IsAuthenticated == false)
            {
                return RedirectToAction("Login");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Login()
        {

            return View();
        }

        //
        // POST: /Home/Delete/5

        [HttpPost]
        public ActionResult Login(Models.User usr, FormCollection frm)
        {
            try
            {
                con = new Models.SalesConn();

                var _usr = con.Users.FirstOrDefault(x => x.User_ID == usr.User_ID && x.Password == usr.Password);
                if (_usr != null)
                {
                    Models.User obj = new Models.User() { Id = _usr.Id, Name = _usr.Name, Role_Id = _usr.Role_Id, User_Branches = _usr.User_Branches.Select(x => new Models.User_Branches { Branch = new Models.Branch() {Id= x.Branch_Id, Name= x.Branch.Name } }).ToArray() };
                    var cookie = FormsAuthentication.GetAuthCookie(_usr.Name, false);
                    var ticket = FormsAuthentication.Decrypt(cookie.Value);
                    string usrdata = JsonConvert.SerializeObject(obj);
                    var newTicket = new FormsAuthenticationTicket(ticket.Version, ticket.Name, ticket.IssueDate, ticket.Expiration, ticket.IsPersistent, usrdata, ticket.CookiePath);
                    var encTicket = FormsAuthentication.Encrypt(newTicket);
                    if (Session.Count > 0)
                    {
                        Session.Clear();
                        Session.Abandon();
                    }
                        Session["Type"] = _usr.Role_Id.ToString();
                        Session.Timeout = 2000;
                    /// Use existing cookie. Could create new one but would have to copy settings over...
                    cookie.Value = encTicket;
                    Response.Cookies.Add(new HttpCookie("FY", frm["fy"]));
                    Response.Cookies.Add(new HttpCookie("Branches", _usr.User_Branches.FirstOrDefault().Branch.Id.ToString()));
                    Response.Cookies.Add(cookie);
                }
                return RedirectToAction("Index", "invoices");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Logout() {
            Session.Abandon();
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

        public ActionResult Config()
        {
            return View();
        }

        //
        // POST: /Home/Delete/5

        [HttpPost]
        public ActionResult Config(Models.User usr)
        {
            try
            {
                con = new Models.SalesConn();

                var _usr = con.Users.FirstOrDefault(x => x.User_ID == usr.User_ID && x.Password == usr.Password);
                if (_usr != null)
                {
                    Models.User obj = new Models.User() { Id = _usr.Id, Name = _usr.Name, Role_Id = _usr.Role_Id, User_Branches = _usr.User_Branches.Select(x => new Models.User_Branches { Branch = new Models.Branch() { Id = x.Branch_Id, Name = x.Branch.Name } }).ToList() };
                    var cookie = FormsAuthentication.GetAuthCookie(_usr.Name, false);
                    var ticket = FormsAuthentication.Decrypt(cookie.Value);
                    string usrdata = JsonConvert.SerializeObject(obj);

                    var newTicket = new FormsAuthenticationTicket(ticket.Version, ticket.Name, ticket.IssueDate, ticket.Expiration, ticket.IsPersistent, usrdata, ticket.CookiePath);
                    var encTicket = FormsAuthentication.Encrypt(newTicket);
                    /// Use existing cookie. Could create new one but would have to copy settings over...
                    cookie.Value = encTicket;
                    Response.Cookies.Add(new HttpCookie("Branches", _usr.User_Branches.FirstOrDefault().Branch.Id.ToString()));
                    Response.Cookies.Add(cookie);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

    }

    public static class common {
        public static int GetBranch_Id(HttpRequestBase r) {
            if (r.Cookies["Branches"] == null)
                return 0;
            else
               return Convert.ToInt32(r.Cookies["Branches"].Value);
        }
    }

    public static class roleName
    {
        public static int GetUserType(HttpRequestBase r)
        {
            if (r.Cookies["Branches"] == null)
                return 0;
            else
                return Convert.ToInt32(r.Cookies["Branches"].Value);
        }
    }
    
}
