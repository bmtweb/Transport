﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace Transport.Controllers
{
    [Authorize]
    public class RatesController : Controller
    {
        //
        // GET: /Rates/

        Models.SalesConn con;
        int pageSize = 10;
        int Branch_id = 0;
        public ActionResult Index(int? page)
        {
            int pageNumber = (page ?? 1);
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y=> y.Branch_Id == Branch_id).Count()> 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
            return View(con.Invoice_Rates.Where(x => x.Branch_Id == Branch_id).OrderBy(x=> x.Id).ToPagedList(pageNumber, pageSize));
        }

        [HttpPost]
        public ActionResult Index(int? page, FormCollection frm)
        {
            int pageNumber = (page ?? 1);
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            int comp_id = Convert.ToInt32(frm[0]=="" ? "0": frm[0] );
            ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name", frm[0]);
            return View(con.Invoice_Rates.Where(x => x.Branch_Id == Branch_id && (comp_id == 0 ? true : comp_id == x.Company_Id)).OrderBy(x => x.Id).ToPagedList(pageNumber, pageSize));
        }
        //
        // GET: /Rates/Edit/5

        public ActionResult Rate(int id)
        {
            con = new Models.SalesConn();
            Branch_id = common.GetBranch_Id(Request);
            Models.Invoice_Rates _f = con.Invoice_Rates.FirstOrDefault(x => x.Id == id);
            ViewBag.Branches = new SelectList(con.Branches.Select(x => new { Id = x.Id, Name = x.Name }), "Id", "Name");

            ViewBag.Suppliers = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 1).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
            ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && x.Type == 2).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
            ViewBag.Tranporters = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Status == true && (x.Type == 3)).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
            ViewBag.Products = new SelectList(con.Products.Where(x => x.Active == true).Select(x => new { x.Name, x.Id }).OrderBy(x => x.Name).ToArray(), "Id", "Name");
            return View(_f ?? new Models.Invoice_Rates());
        }

        //
        // POST: /Rates/Edit/5

        [HttpPost]
        public ActionResult Rate(Models.Invoice_Rates R)
        {
            try
            {
                Branch_id = common.GetBranch_Id(Request);
                con = new Models.SalesConn();
                Models.Invoice_Rates _r = con.Invoice_Rates.FirstOrDefault(x => x.Company_Id == R.Company_Id && x.Supplier_Id == R.Supplier_Id && x.Transport_Id == R.Transport_Id && x.Product_Id == R.Product_Id);
                if (_r == null)
                    _r = new Models.Invoice_Rates();
                _r.Branch_Id = R.Branch_Id;
                _r.Active = R.Active;
                _r.Company_Id = R.Company_Id;
                _r.Product_Id = R.Product_Id;
                _r.B_Rate = R.B_Rate;
                _r.C_Rate = R.C_Rate;
                _r.Supplier_Id = R.Supplier_Id;
                _r.Transport_Id = R.Transport_Id;
                _r.Active = R.Active;
                if (_r.Id == 0)
                    con.Invoice_Rates.Add(_r);
                con.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                con = new Models.SalesConn();
                Models.Invoice_Rates _f = con.Invoice_Rates.FirstOrDefault(x => x.Id == id);
                if (_f != null)
                    con.Invoice_Rates.Remove(_f);
                con.SaveChanges();
                TempData["message"] = "Deleted Successfully";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                TempData["message"] = "Connot deleted this record!";
                return RedirectToAction("Index");
            }

        }
    }
}
