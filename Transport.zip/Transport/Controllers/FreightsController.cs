﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace Transport.Controllers
{
    [Authorize]
    public class FreightsController : Controller
    {
        //
        // GET: /Freights/
        int pageSize = 10;
        int Branch_id = 0;
        Models.SalesConn con;
        public ActionResult Index(int? page)
        {
            int pageNumber = (page ?? 1);
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            return View(con.Freights.Where(x=> x.Branch_Id == Branch_id).OrderBy(x=> x.From_Place).ToPagedList(pageNumber, pageSize));
        }

        //
        // GET: /Freights/Create

        public ActionResult Freight(int id)
        {
            Branch_id = common.GetBranch_Id(Request);
            con = new Models.SalesConn();
            Models.Freight _f = con.Freights.FirstOrDefault(x => x.Id == id);
            if (_f==null)
                _f = new Models.Freight();
            ViewBag.Supplier = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Type == 1 && x.Status ==true).Select(x => new { x.City }).OrderBy(x => x.City).Distinct().ToArray(), "City", "City", _f.From_Place);
            ViewBag.Companies = new SelectList(con.Companies.Where(x => x.Company_Branches.Where(y => y.Branch_Id == Branch_id).Count() > 0 && x.Type == 2 && x.Status == true).Select(x => new { x.City }).OrderBy(x => x.City).Distinct().ToArray(), "City", "City", _f.To_Place);
            return View(_f);
        }

        //
        // POST: /Freights/Create

        [HttpPost]
        public ActionResult Freight(Models.Freight f)
        {
            try
            {
                Branch_id = common.GetBranch_Id(Request);
                con = new Models.SalesConn();
                Models.Freight _f = con.Freights.FirstOrDefault(x => x.Id == f.Id && x.Branch_Id== Branch_id);
                if (_f == null)
                    _f = new Models.Freight();
                _f.Branch_Id = Branch_id;
                _f.From_Place = f.From_Place;
                _f.To_Place = f.To_Place;
                _f.Rate = f.Rate;
                if (_f.Id == 0)
                    con.Freights.Add(_f);
                con.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                con = new Models.SalesConn();
                Models.Freight _f = con.Freights.FirstOrDefault(x => x.Id == id);
                if (_f != null)
                    con.Freights.Remove(_f);
                con.SaveChanges();
                TempData["message"] = "Deleted Successfully";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                TempData["message"] = "Connot deleted this record!";
                return RedirectToAction("Index");
            }

        }
        
    }
}
