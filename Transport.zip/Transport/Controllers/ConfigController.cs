﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Transport.Controllers
{
    public class ConfigController : Controller
    {
        Models.SalesConn con;
        public ActionResult Taxes()
        {
            con = new Models.SalesConn();
            Models.Config[] arr = con.Configs.ToArray();

            Models.Taxes tax = new Models.Taxes();
            tax.VAT = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "VAT_Rate").Value);
            tax.Other_VAT = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "Other_VAT_Rate").Value);
            tax.ServiceTax = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "Service_Tax").Value);
            tax.Education_Cess = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "EC_Tax").Value);
            tax.SHEC = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "HEC_Tax").Value);
            tax.Taxable = Convert.ToDecimal(arr.FirstOrDefault(x => x.Variable == "TAXABLE").Value);
            return View(tax);
        }

        [HttpPost]
        public ActionResult Taxes(Models.Taxes tax)
        {
            con = new Models.SalesConn();
            Models.Config[] arr = con.Configs.ToArray();
            arr.FirstOrDefault(x => x.Variable == "Other_VAT_Rate").Value = tax.Other_VAT.ToString();
            arr.FirstOrDefault(x => x.Variable == "VAT_Rate").Value = tax.VAT.ToString();
            arr.FirstOrDefault(x => x.Variable == "Service_Tax").Value = tax.ServiceTax.ToString();
            arr.FirstOrDefault(x => x.Variable == "EC_Tax").Value = tax.Education_Cess.ToString();
            arr.FirstOrDefault(x => x.Variable == "HEC_Tax").Value = tax.SHEC.ToString();
            arr.FirstOrDefault(x => x.Variable == "TAXABLE").Value = tax.Taxable.ToString();
            con.SaveChanges();
            TempData["message"] = "Updated Successfully";
            return View(tax);
        }
       
    }
}
