﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace Transport.Controllers
{
    [Authorize]
    public class MinesController : Controller
    {
        //
        // GET: /Mines/

        Models.SalesConn con;
        int pageSize = 10;
        //int Branch_id = 0;
        public ActionResult Index(int? page)
        {
            //Branch_id = common.GetBranch_Id(Request);
            int pageNumber = (page ?? 1);
            con = new Models.SalesConn();
            return View(con.Mines.OrderBy(x => x.Name).ToPagedList(pageNumber, pageSize));
        }

        //
        // GET: /Mines/Create
        public ActionResult Mine(int id)
        {
            con = new Models.SalesConn();
            //ViewBag.Branches = con.Branches.ToList();
            Models.Mine _p = con.Mines.FirstOrDefault(x => x.Id == id);
            return View(_p ?? new Models.Mine());
        }

        //
        // POST: /Materials/Create

        [HttpPost]
        public ActionResult Mine(Models.Mine _pro, FormCollection frm)
        {
            try
            {
                con = new Models.SalesConn();

                Models.Mine pro = con.Mines.FirstOrDefault(x => x.Id == _pro.Id);
                if (pro == null)
                    pro = new Models.Mine();
                pro.Name = _pro.Name;
                pro.Status = _pro.Status;

                if (pro.Id == 0)
                    con.Mines.Add(pro);
                con.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                con = new Models.SalesConn();
                Models.Mine pro = con.Mines.FirstOrDefault(x => x.Id == id);
                if (pro != null)
                    con.Mines.Remove(pro);
                con.SaveChanges();
                TempData["message"] = "Mines Name Deleted Successfully";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                TempData["message"] = "Error on deleting this Mines Detail!";
                return RedirectToAction("Index");
            }
        }
    }
}
