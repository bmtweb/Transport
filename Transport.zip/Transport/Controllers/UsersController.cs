﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace Transport.Controllers
{
    
    public class UsersController : Controller
    {
        //
        // GET: /Users/
        Models.SalesConn con;
        int pageSize = 1;
        public ActionResult Index(int? page)
        {
            int pageNumber = (page ?? 1);
            con = new Models.SalesConn();
            return View(con.Users.OrderBy(x => x.Name).ToPagedList(pageNumber, pageSize));
        }

        //
        // GET: /Users/Edit/5

        public ActionResult user(int id)
        {
            con = new Models.SalesConn();

            Models.User _con = con.Users.FirstOrDefault(x => x.Id == id);
            ViewBag.Roles = new SelectList(con.Roles.Select(x => new { x.Id, x.Name }), "Id", "Name");
            ViewBag.Branches = con.Branches.ToList();
            return View(_con ?? new Models.User());
        }

        //
        // POST: /Users/Edit/5

        [HttpPost]
        public ActionResult user(int id, Models.User _user, FormCollection frm)
        {
            try
            {
                con = new Models.SalesConn();
                ViewBag.Roles = new SelectList(con.Roles.Select(x => new { x.Id, x.Name }), "Id", "Name");
                Models.User usr = con.Users.FirstOrDefault(x => x.Id == _user.Id);
                if (usr == null)
                    usr = new Models.User();

                usr.Name = _user.Name;
                usr.Address = _user.Address;
                usr.City = _user.City;
                usr.Email = _user.Email;
                usr.Phone = _user.Phone;
                usr.User_ID = _user.User_ID;
                usr.Password = _user.Password;
                usr.State = _user.State;
                usr.Role_Id = _user.Role_Id;
                usr.Zip = _user.Zip;

                Models.User_Branches[] brs = usr.User_Branches.ToArray();
                foreach (var item in brs)
                {
                    con.User_Branches.Remove(item);
                }

                foreach (var item in frm.AllKeys.Where(x=> x.Contains("chk_")))
                {
                    if (frm[item]== "on")
                    {
                        usr.User_Branches.Add(new Models.User_Branches() { Branch_Id= Convert.ToInt32(item.Split('_')[1]), User_Id= usr.Id });
                    }
                }

                if (_user.Id == 0)
                    con.Users.Add(usr);
                con.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult permission(int? id)
        {
            con = new Models.SalesConn();
            var l = con.Roles.Select(x => new { x.Id, x.Name });
            ViewBag.Roles = new SelectList(l, "Id", "Name", id??0);
            ViewBag.Menus = con.Menus.ToList();
            return View(con.Permissions.Where(x=>x.Role_Id == (id?? l.FirstOrDefault().Id)).ToList());
        }

        //
        // POST: /Users/Edit/5

        [HttpPost]
        public ActionResult permission(FormCollection collection)
        {
            try
            {
                con = new Models.SalesConn();
                var l = con.Roles.Select(x => new { x.Id, x.Name });
                ViewBag.Roles = new SelectList(l, "Id", "Name", collection["Role_Id"]);
                ViewBag.Menus = con.Menus.ToList();
                int Role_Id = Convert.ToInt32(collection["Role_Id"]);
                Models.Permission[] prs = con.Permissions.Where(x => x.Role_Id == Role_Id).ToArray();
                foreach (var item in prs)
                    con.Permissions.Remove(item);

                con.SaveChanges();

                foreach (var item in collection.AllKeys.Where(x=> x.Contains("chk_")))
                {
                    if (collection[item] == "on")
                    {
                        con.Permissions.Add(new Models.Permission() { Role_Id = Role_Id, Menu_Id = Convert.ToInt32(item.Split('_')[1]), Access = true });
                    }
                }
                con.SaveChanges();
                return View(con.Permissions.Where(x => x.Role_Id == Role_Id).ToList());
            }
            catch
            {
                return View();
            }
        }

    }
}
