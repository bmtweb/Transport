
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 07/12/2015 13:28:25
-- Generated from EDMX file: D:\P R O J E C T S\NEW PROJECTS\smsbilling\Transport\Models\dbModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Sales];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_Company_Branches_Branches]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Company_Branches] DROP CONSTRAINT [FK_Company_Branches_Branches];
GO
IF OBJECT_ID(N'[dbo].[FK_Company_Branches_Companies]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Company_Branches] DROP CONSTRAINT [FK_Company_Branches_Companies];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoice_Rates_Branches]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoice_Rates] DROP CONSTRAINT [FK_Invoice_Rates_Branches];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoice_Rates_Companies]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoice_Rates] DROP CONSTRAINT [FK_Invoice_Rates_Companies];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoice_Rates_Companies1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoice_Rates] DROP CONSTRAINT [FK_Invoice_Rates_Companies1];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoice_Rates_Companies2]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoice_Rates] DROP CONSTRAINT [FK_Invoice_Rates_Companies2];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoice_Rates_Products]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoice_Rates] DROP CONSTRAINT [FK_Invoice_Rates_Products];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoices_Branches]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoices] DROP CONSTRAINT [FK_Invoices_Branches];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoices_Companies]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoices] DROP CONSTRAINT [FK_Invoices_Companies];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoices_Companies1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoices] DROP CONSTRAINT [FK_Invoices_Companies1];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoices_Companies3]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoices] DROP CONSTRAINT [FK_Invoices_Companies3];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoices_Loadings]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoices] DROP CONSTRAINT [FK_Invoices_Loadings];
GO
IF OBJECT_ID(N'[dbo].[FK_Invoices_Products]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Invoices] DROP CONSTRAINT [FK_Invoices_Products];
GO
IF OBJECT_ID(N'[dbo].[FK_Permissions_Menus]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Permissions] DROP CONSTRAINT [FK_Permissions_Menus];
GO
IF OBJECT_ID(N'[dbo].[FK_Permissions_Roles]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Permissions] DROP CONSTRAINT [FK_Permissions_Roles];
GO
IF OBJECT_ID(N'[dbo].[FK_Product_Branches_Branches]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Product_Branches] DROP CONSTRAINT [FK_Product_Branches_Branches];
GO
IF OBJECT_ID(N'[dbo].[FK_Product_Branches_Products]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Product_Branches] DROP CONSTRAINT [FK_Product_Branches_Products];
GO
IF OBJECT_ID(N'[dbo].[FK_Receipts_Companies]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Receipts] DROP CONSTRAINT [FK_Receipts_Companies];
GO
IF OBJECT_ID(N'[dbo].[FK_Receipts_Companies1]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Receipts] DROP CONSTRAINT [FK_Receipts_Companies1];
GO
IF OBJECT_ID(N'[dbo].[FK_Transactions_CompaniesCR]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Transactions] DROP CONSTRAINT [FK_Transactions_CompaniesCR];
GO
IF OBJECT_ID(N'[dbo].[FK_Transactions_CompaniesDR]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Transactions] DROP CONSTRAINT [FK_Transactions_CompaniesDR];
GO
IF OBJECT_ID(N'[dbo].[FK_User_Branches_Branches]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User_Branches] DROP CONSTRAINT [FK_User_Branches_Branches];
GO
IF OBJECT_ID(N'[dbo].[FK_User_Branches_Users]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[User_Branches] DROP CONSTRAINT [FK_User_Branches_Users];
GO
IF OBJECT_ID(N'[dbo].[FK_Users_Roles]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Users] DROP CONSTRAINT [FK_Users_Roles];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Branches]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Branches];
GO
IF OBJECT_ID(N'[dbo].[Companies]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Companies];
GO
IF OBJECT_ID(N'[dbo].[Company_Branches]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Company_Branches];
GO
IF OBJECT_ID(N'[dbo].[Config]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Config];
GO
IF OBJECT_ID(N'[dbo].[Freights]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Freights];
GO
IF OBJECT_ID(N'[dbo].[Invoice_Rates]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Invoice_Rates];
GO
IF OBJECT_ID(N'[dbo].[Invoices]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Invoices];
GO
IF OBJECT_ID(N'[dbo].[Loadings]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Loadings];
GO
IF OBJECT_ID(N'[dbo].[Menus]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Menus];
GO
IF OBJECT_ID(N'[dbo].[Permissions]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Permissions];
GO
IF OBJECT_ID(N'[dbo].[Product_Branches]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Product_Branches];
GO
IF OBJECT_ID(N'[dbo].[Products]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Products];
GO
IF OBJECT_ID(N'[dbo].[Receipts]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Receipts];
GO
IF OBJECT_ID(N'[dbo].[Roles]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Roles];
GO
IF OBJECT_ID(N'[dbo].[Transactions]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Transactions];
GO
IF OBJECT_ID(N'[dbo].[Types]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Types];
GO
IF OBJECT_ID(N'[dbo].[User_Branches]', 'U') IS NOT NULL
    DROP TABLE [dbo].[User_Branches];
GO
IF OBJECT_ID(N'[dbo].[Users]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Users];
GO
IF OBJECT_ID(N'[dbo].[Vehicles]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Vehicles];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Branches'
CREATE TABLE [dbo].[Branches] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(50)  NOT NULL,
    [Address] varchar(150)  NOT NULL,
    [City] varchar(50)  NOT NULL,
    [State] varchar(50)  NOT NULL,
    [Zip] varchar(50)  NOT NULL,
    [Tin] varchar(12)  NOT NULL
);
GO

-- Creating table 'Companies'
CREATE TABLE [dbo].[Companies] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Type] int  NOT NULL,
    [Name] varchar(150)  NOT NULL,
    [Unit_Name] varchar(150)  NULL,
    [Address] varchar(150)  NOT NULL,
    [City] varchar(100)  NOT NULL,
    [State] varchar(100)  NOT NULL,
    [Zip] varchar(10)  NOT NULL,
    [Dist] varchar(100)  NOT NULL,
    [Email] varchar(50)  NULL,
    [Phone_1] varchar(12)  NULL,
    [Phone_2] varchar(12)  NULL,
    [Mobile] varchar(12)  NULL,
    [Fax] varchar(12)  NULL,
    [CST_NO] varchar(50)  NULL,
    [GST_NO] varchar(50)  NULL,
    [Bank] varchar(50)  NULL,
    [Account_No] varchar(50)  NULL,
    [RTGS] varchar(50)  NULL,
    [Status] bit  NOT NULL,
    [BillType] varchar(15)  NULL,
    [Reg_No] varchar(50)  NULL,
    [Pan_No] varchar(50)  NULL,
    [TIN] varchar(50)  NULL
);
GO

-- Creating table 'Company_Branches'
CREATE TABLE [dbo].[Company_Branches] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Branch_Id] int  NOT NULL,
    [Company_Id] int  NOT NULL
);
GO

-- Creating table 'Configs'
CREATE TABLE [dbo].[Configs] (
    [Id] int  NOT NULL,
    [Variable] varchar(50)  NOT NULL,
    [Value] varchar(50)  NOT NULL
);
GO

-- Creating table 'Freights'
CREATE TABLE [dbo].[Freights] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Branch_Id] int  NOT NULL,
    [From_Place] varchar(50)  NOT NULL,
    [To_Place] varchar(50)  NOT NULL,
    [Rate] decimal(18,2)  NOT NULL
);
GO

-- Creating table 'Invoice_Rates'
CREATE TABLE [dbo].[Invoice_Rates] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Branch_Id] int  NOT NULL,
    [Company_Id] int  NOT NULL,
    [Supplier_Id] int  NOT NULL,
    [Product_Id] int  NOT NULL,
    [Transport_Id] int  NOT NULL,
    [B_Rate] decimal(18,2)  NOT NULL,
    [C_Rate] decimal(18,2)  NOT NULL,
    [Active] bit  NOT NULL
);
GO

-- Creating table 'Invoices'
CREATE TABLE [dbo].[Invoices] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Invoice_Date] datetime  NOT NULL,
    [Branch_Id] int  NOT NULL,
    [Billty_No] int  NOT NULL,
    [Invoice_No] int  NOT NULL,
    [Company_Id] int  NOT NULL,
    [Transport_Id] int  NOT NULL,
    [Product_Id] int  NOT NULL,
    [Second_Transport_Id] int  NOT NULL,
    [Supplier_Id] int  NOT NULL,
    [Truck_No] varchar(50)  NOT NULL,
    [Form_No] int  NOT NULL,
    [Pan_Card] varchar(10)  NOT NULL,
    [Royalty_No] varchar(10)  NOT NULL,
    [Code_1] decimal(18,2)  NOT NULL,
    [Code_2] decimal(18,2)  NOT NULL,
    [Advance] decimal(18,2)  NOT NULL,
    [BillType] varchar(15)  NOT NULL,
    [Weight] decimal(18,2)  NOT NULL,
    [Freight_Rate] decimal(18,2)  NOT NULL,
    [Freight] decimal(18,2)  NOT NULL,
    [Invoice_Amount] decimal(18,2)  NOT NULL,
    [B_Rate] decimal(18,2)  NOT NULL,
    [C_Rate] decimal(18,2)  NOT NULL,
    [VAT_Rate] decimal(18,2)  NOT NULL,
    [VAT_Amount] decimal(18,2)  NOT NULL,
    [Paid_Date] datetime  NULL,
    [Paid_Amount] decimal(18,2)  NULL,
    [Deposit_Amount] decimal(18,2)  NOT NULL,
    [Loading_Id] int  NOT NULL,
    [From_City] varchar(150)  NULL,
    [To_City] varchar(150)  NULL,
    [Pan_No] nvarchar(15)  NOT NULL,
    [Owner_Name] nvarchar(max)  NULL,
    [Driver_Name] nvarchar(max)  NULL,
    [Driver_Address] nvarchar(20)  NULL,
    [Driver_License] nvarchar(6)  NULL
);
GO

-- Creating table 'Loadings'
CREATE TABLE [dbo].[Loadings] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(100)  NOT NULL
);
GO

-- Creating table 'Menus'
CREATE TABLE [dbo].[Menus] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Menu1] varchar(50)  NOT NULL,
    [Url] varchar(150)  NOT NULL,
    [Rank] int  NOT NULL,
    [Perent_Id] int  NOT NULL
);
GO

-- Creating table 'Permissions'
CREATE TABLE [dbo].[Permissions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Role_Id] int  NOT NULL,
    [Menu_Id] int  NOT NULL,
    [Access] bit  NOT NULL
);
GO

-- Creating table 'Product_Branches'
CREATE TABLE [dbo].[Product_Branches] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Product_Id] int  NOT NULL,
    [Branch_Id] int  NOT NULL
);
GO

-- Creating table 'Products'
CREATE TABLE [dbo].[Products] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(150)  NOT NULL,
    [Active] bit  NOT NULL
);
GO

-- Creating table 'Receipts'
CREATE TABLE [dbo].[Receipts] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Receipt_No] varchar(50)  NOT NULL,
    [Receipt_Date] datetime  NOT NULL,
    [Cr_Account_Id] int  NOT NULL,
    [Dr_Account_Id] int  NOT NULL,
    [Bank] varchar(250)  NOT NULL,
    [Amount] decimal(18,2)  NOT NULL,
    [Cheque] varchar(15)  NOT NULL
);
GO

-- Creating table 'Roles'
CREATE TABLE [dbo].[Roles] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(50)  NOT NULL
);
GO

-- Creating table 'Transactions'
CREATE TABLE [dbo].[Transactions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Voucher_No] varchar(50)  NOT NULL,
    [Voucher_Date] datetime  NOT NULL,
    [Cr_Account_Id] int  NOT NULL,
    [Dr_Account_Id] int  NOT NULL,
    [Particular] varchar(250)  NOT NULL,
    [Amount1] decimal(18,2)  NOT NULL,
    [Amount2] decimal(18,2)  NOT NULL,
    [DrCr] char(2)  NOT NULL
);
GO

-- Creating table 'Types'
CREATE TABLE [dbo].[Types] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(50)  NOT NULL
);
GO

-- Creating table 'User_Branches'
CREATE TABLE [dbo].[User_Branches] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Branch_Id] int  NOT NULL,
    [User_Id] int  NOT NULL
);
GO

-- Creating table 'Users'
CREATE TABLE [dbo].[Users] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(50)  NOT NULL,
    [Address] varchar(50)  NOT NULL,
    [City] varchar(50)  NOT NULL,
    [State] varchar(50)  NOT NULL,
    [Zip] varchar(10)  NOT NULL,
    [Phone] varchar(12)  NOT NULL,
    [Email] varchar(50)  NOT NULL,
    [User_ID] varchar(15)  NOT NULL,
    [Password] varchar(15)  NOT NULL,
    [Role_Id] int  NOT NULL
);
GO

-- Creating table 'Vehicles'
CREATE TABLE [dbo].[Vehicles] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(15)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Branches'
ALTER TABLE [dbo].[Branches]
ADD CONSTRAINT [PK_Branches]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Companies'
ALTER TABLE [dbo].[Companies]
ADD CONSTRAINT [PK_Companies]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Company_Branches'
ALTER TABLE [dbo].[Company_Branches]
ADD CONSTRAINT [PK_Company_Branches]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Configs'
ALTER TABLE [dbo].[Configs]
ADD CONSTRAINT [PK_Configs]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Freights'
ALTER TABLE [dbo].[Freights]
ADD CONSTRAINT [PK_Freights]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Invoice_Rates'
ALTER TABLE [dbo].[Invoice_Rates]
ADD CONSTRAINT [PK_Invoice_Rates]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Invoices'
ALTER TABLE [dbo].[Invoices]
ADD CONSTRAINT [PK_Invoices]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Loadings'
ALTER TABLE [dbo].[Loadings]
ADD CONSTRAINT [PK_Loadings]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Menus'
ALTER TABLE [dbo].[Menus]
ADD CONSTRAINT [PK_Menus]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Permissions'
ALTER TABLE [dbo].[Permissions]
ADD CONSTRAINT [PK_Permissions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Product_Branches'
ALTER TABLE [dbo].[Product_Branches]
ADD CONSTRAINT [PK_Product_Branches]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Products'
ALTER TABLE [dbo].[Products]
ADD CONSTRAINT [PK_Products]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Receipts'
ALTER TABLE [dbo].[Receipts]
ADD CONSTRAINT [PK_Receipts]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Roles'
ALTER TABLE [dbo].[Roles]
ADD CONSTRAINT [PK_Roles]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Transactions'
ALTER TABLE [dbo].[Transactions]
ADD CONSTRAINT [PK_Transactions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Types'
ALTER TABLE [dbo].[Types]
ADD CONSTRAINT [PK_Types]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'User_Branches'
ALTER TABLE [dbo].[User_Branches]
ADD CONSTRAINT [PK_User_Branches]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [PK_Users]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Vehicles'
ALTER TABLE [dbo].[Vehicles]
ADD CONSTRAINT [PK_Vehicles]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Branch_Id] in table 'Company_Branches'
ALTER TABLE [dbo].[Company_Branches]
ADD CONSTRAINT [FK_Company_Branches_Branches]
    FOREIGN KEY ([Branch_Id])
    REFERENCES [dbo].[Branches]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Company_Branches_Branches'
CREATE INDEX [IX_FK_Company_Branches_Branches]
ON [dbo].[Company_Branches]
    ([Branch_Id]);
GO

-- Creating foreign key on [Branch_Id] in table 'Invoice_Rates'
ALTER TABLE [dbo].[Invoice_Rates]
ADD CONSTRAINT [FK_Invoice_Rates_Branches]
    FOREIGN KEY ([Branch_Id])
    REFERENCES [dbo].[Branches]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoice_Rates_Branches'
CREATE INDEX [IX_FK_Invoice_Rates_Branches]
ON [dbo].[Invoice_Rates]
    ([Branch_Id]);
GO

-- Creating foreign key on [Branch_Id] in table 'Invoices'
ALTER TABLE [dbo].[Invoices]
ADD CONSTRAINT [FK_Invoices_Branches]
    FOREIGN KEY ([Branch_Id])
    REFERENCES [dbo].[Branches]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoices_Branches'
CREATE INDEX [IX_FK_Invoices_Branches]
ON [dbo].[Invoices]
    ([Branch_Id]);
GO

-- Creating foreign key on [Branch_Id] in table 'Product_Branches'
ALTER TABLE [dbo].[Product_Branches]
ADD CONSTRAINT [FK_Product_Branches_Branches]
    FOREIGN KEY ([Branch_Id])
    REFERENCES [dbo].[Branches]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Product_Branches_Branches'
CREATE INDEX [IX_FK_Product_Branches_Branches]
ON [dbo].[Product_Branches]
    ([Branch_Id]);
GO

-- Creating foreign key on [Branch_Id] in table 'User_Branches'
ALTER TABLE [dbo].[User_Branches]
ADD CONSTRAINT [FK_User_Branches_Branches]
    FOREIGN KEY ([Branch_Id])
    REFERENCES [dbo].[Branches]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_User_Branches_Branches'
CREATE INDEX [IX_FK_User_Branches_Branches]
ON [dbo].[User_Branches]
    ([Branch_Id]);
GO

-- Creating foreign key on [Company_Id] in table 'Company_Branches'
ALTER TABLE [dbo].[Company_Branches]
ADD CONSTRAINT [FK_Company_Branches_Companies]
    FOREIGN KEY ([Company_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Company_Branches_Companies'
CREATE INDEX [IX_FK_Company_Branches_Companies]
ON [dbo].[Company_Branches]
    ([Company_Id]);
GO

-- Creating foreign key on [Supplier_Id] in table 'Invoice_Rates'
ALTER TABLE [dbo].[Invoice_Rates]
ADD CONSTRAINT [FK_Invoice_Rates_Companies]
    FOREIGN KEY ([Supplier_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoice_Rates_Companies'
CREATE INDEX [IX_FK_Invoice_Rates_Companies]
ON [dbo].[Invoice_Rates]
    ([Supplier_Id]);
GO

-- Creating foreign key on [Company_Id] in table 'Invoice_Rates'
ALTER TABLE [dbo].[Invoice_Rates]
ADD CONSTRAINT [FK_Invoice_Rates_Companies1]
    FOREIGN KEY ([Company_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoice_Rates_Companies1'
CREATE INDEX [IX_FK_Invoice_Rates_Companies1]
ON [dbo].[Invoice_Rates]
    ([Company_Id]);
GO

-- Creating foreign key on [Transport_Id] in table 'Invoice_Rates'
ALTER TABLE [dbo].[Invoice_Rates]
ADD CONSTRAINT [FK_Invoice_Rates_Companies2]
    FOREIGN KEY ([Transport_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoice_Rates_Companies2'
CREATE INDEX [IX_FK_Invoice_Rates_Companies2]
ON [dbo].[Invoice_Rates]
    ([Transport_Id]);
GO

-- Creating foreign key on [Company_Id] in table 'Invoices'
ALTER TABLE [dbo].[Invoices]
ADD CONSTRAINT [FK_Invoices_Companies]
    FOREIGN KEY ([Company_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoices_Companies'
CREATE INDEX [IX_FK_Invoices_Companies]
ON [dbo].[Invoices]
    ([Company_Id]);
GO

-- Creating foreign key on [Transport_Id] in table 'Invoices'
ALTER TABLE [dbo].[Invoices]
ADD CONSTRAINT [FK_Invoices_Companies1]
    FOREIGN KEY ([Transport_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoices_Companies1'
CREATE INDEX [IX_FK_Invoices_Companies1]
ON [dbo].[Invoices]
    ([Transport_Id]);
GO

-- Creating foreign key on [Supplier_Id] in table 'Invoices'
ALTER TABLE [dbo].[Invoices]
ADD CONSTRAINT [FK_Invoices_Companies3]
    FOREIGN KEY ([Supplier_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoices_Companies3'
CREATE INDEX [IX_FK_Invoices_Companies3]
ON [dbo].[Invoices]
    ([Supplier_Id]);
GO

-- Creating foreign key on [Cr_Account_Id] in table 'Receipts'
ALTER TABLE [dbo].[Receipts]
ADD CONSTRAINT [FK_Receipts_Companies]
    FOREIGN KEY ([Cr_Account_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Receipts_Companies'
CREATE INDEX [IX_FK_Receipts_Companies]
ON [dbo].[Receipts]
    ([Cr_Account_Id]);
GO

-- Creating foreign key on [Dr_Account_Id] in table 'Receipts'
ALTER TABLE [dbo].[Receipts]
ADD CONSTRAINT [FK_Receipts_Companies1]
    FOREIGN KEY ([Dr_Account_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Receipts_Companies1'
CREATE INDEX [IX_FK_Receipts_Companies1]
ON [dbo].[Receipts]
    ([Dr_Account_Id]);
GO

-- Creating foreign key on [Cr_Account_Id] in table 'Transactions'
ALTER TABLE [dbo].[Transactions]
ADD CONSTRAINT [FK_Transactions_CompaniesCR]
    FOREIGN KEY ([Cr_Account_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Transactions_CompaniesCR'
CREATE INDEX [IX_FK_Transactions_CompaniesCR]
ON [dbo].[Transactions]
    ([Cr_Account_Id]);
GO

-- Creating foreign key on [Dr_Account_Id] in table 'Transactions'
ALTER TABLE [dbo].[Transactions]
ADD CONSTRAINT [FK_Transactions_CompaniesDR]
    FOREIGN KEY ([Dr_Account_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Transactions_CompaniesDR'
CREATE INDEX [IX_FK_Transactions_CompaniesDR]
ON [dbo].[Transactions]
    ([Dr_Account_Id]);
GO

-- Creating foreign key on [Product_Id] in table 'Invoice_Rates'
ALTER TABLE [dbo].[Invoice_Rates]
ADD CONSTRAINT [FK_Invoice_Rates_Products]
    FOREIGN KEY ([Product_Id])
    REFERENCES [dbo].[Products]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoice_Rates_Products'
CREATE INDEX [IX_FK_Invoice_Rates_Products]
ON [dbo].[Invoice_Rates]
    ([Product_Id]);
GO

-- Creating foreign key on [Loading_Id] in table 'Invoices'
ALTER TABLE [dbo].[Invoices]
ADD CONSTRAINT [FK_Invoices_Loadings]
    FOREIGN KEY ([Loading_Id])
    REFERENCES [dbo].[Loadings]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoices_Loadings'
CREATE INDEX [IX_FK_Invoices_Loadings]
ON [dbo].[Invoices]
    ([Loading_Id]);
GO

-- Creating foreign key on [Product_Id] in table 'Invoices'
ALTER TABLE [dbo].[Invoices]
ADD CONSTRAINT [FK_Invoices_Products]
    FOREIGN KEY ([Product_Id])
    REFERENCES [dbo].[Products]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Invoices_Products'
CREATE INDEX [IX_FK_Invoices_Products]
ON [dbo].[Invoices]
    ([Product_Id]);
GO

-- Creating foreign key on [Menu_Id] in table 'Permissions'
ALTER TABLE [dbo].[Permissions]
ADD CONSTRAINT [FK_Permissions_Menus]
    FOREIGN KEY ([Menu_Id])
    REFERENCES [dbo].[Menus]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Permissions_Menus'
CREATE INDEX [IX_FK_Permissions_Menus]
ON [dbo].[Permissions]
    ([Menu_Id]);
GO

-- Creating foreign key on [Role_Id] in table 'Permissions'
ALTER TABLE [dbo].[Permissions]
ADD CONSTRAINT [FK_Permissions_Roles]
    FOREIGN KEY ([Role_Id])
    REFERENCES [dbo].[Roles]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Permissions_Roles'
CREATE INDEX [IX_FK_Permissions_Roles]
ON [dbo].[Permissions]
    ([Role_Id]);
GO

-- Creating foreign key on [Product_Id] in table 'Product_Branches'
ALTER TABLE [dbo].[Product_Branches]
ADD CONSTRAINT [FK_Product_Branches_Products]
    FOREIGN KEY ([Product_Id])
    REFERENCES [dbo].[Products]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Product_Branches_Products'
CREATE INDEX [IX_FK_Product_Branches_Products]
ON [dbo].[Product_Branches]
    ([Product_Id]);
GO

-- Creating foreign key on [Role_Id] in table 'Users'
ALTER TABLE [dbo].[Users]
ADD CONSTRAINT [FK_Users_Roles]
    FOREIGN KEY ([Role_Id])
    REFERENCES [dbo].[Roles]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Users_Roles'
CREATE INDEX [IX_FK_Users_Roles]
ON [dbo].[Users]
    ([Role_Id]);
GO

-- Creating foreign key on [User_Id] in table 'User_Branches'
ALTER TABLE [dbo].[User_Branches]
ADD CONSTRAINT [FK_User_Branches_Users]
    FOREIGN KEY ([User_Id])
    REFERENCES [dbo].[Users]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_User_Branches_Users'
CREATE INDEX [IX_FK_User_Branches_Users]
ON [dbo].[User_Branches]
    ([User_Id]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------