﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Transport.Models
{
    public class Taxes
    {
        [Required]
        [Display(Name = "VAT % (In State)")]
        public decimal VAT { get; set; }

        [Required]
        [Display(Name = "VAT % (Other State)")]
        public decimal Other_VAT { get; set; }

        [Required]
        [Display(Name = "Taxable Amount %")]
        public decimal Taxable { get; set; }

        [Required]
        [Display(Name = "Service Tax Rate %")]
        public decimal ServiceTax { get; set; }

        [Required]
        [Display(Name = "Education Cess %")]
        public decimal Education_Cess { get; set; }

        [Required]
        [Display(Name = "Senior & Higher Education Cess %")]
        public decimal SHEC { get; set; }

    }
}