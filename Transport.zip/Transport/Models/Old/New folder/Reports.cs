﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Transport.Models
{
    public class Account_Report
    {
        [Display(Name = "Select Branch")]
        public int? Branch_Id { get; set; }

        [Display(Name = "From Party")]
        public int? Cr_Account_Id { get; set; }

        [Display(Name = "To Party")]
        public int? Dr_Account_Id { get; set; }

        [Display(Name = "Material")]
        public int? Product_Id { get; set; }

        [Display(Name = "Secondary Tranport")]
        public int? Sec_Tranport_Id { get; set; }

        [Required]
        [Display(Name = "From Date")]
        public DateTime From_Date { get; set; }

        [Required]
        [Display(Name = "To Date")]
        public DateTime To_Date { get; set; }

        [Required]
        [Display(Name = "Report Type")]
        public int ReportType { get; set; }

        [Required]
        [Display(Name = "Rate By")]
        public int RateBy { get; set; }
    }
}